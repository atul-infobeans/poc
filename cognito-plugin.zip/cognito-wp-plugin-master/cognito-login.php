<?php

/**
 *    
 * @wordpress-plugin
 * Plugin Name:       ICC SSO 2.0
 * Description:       AWS Cognito Login for ICC Sites.
 * Version:           1.0.5
 * Author:            ICC
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

// Define plugin version 
define( 'AWS_VERSION_LOGIN', '1.0.5');

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-cognito-login-activator.php
 */
function aws_acl_activate_cognito_login() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cognito-login-activator.php';
	CognitoLoginActivator::activate();
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-cognito-login-deactivator.php
 */
function aws_acl_deactivate_cognito_login() {
	require_once plugin_dir_path( __FILE__ ) . 'includes/class-cognito-login-deactivator.php';
	CognitoLoginDeactivator::deactivate();
}

register_activation_hook( __FILE__, 'aws_acl_activate_cognito_login' );
register_deactivation_hook( __FILE__, 'aws_acl_deactivate_cognito_login' );

/** 
 * admin-specific hooks, and public-facing site hooks.
 */

require plugin_dir_path( __FILE__ ) . 'includes/class-cognito-login.php';

/**
 * COMPOSER
 */

require plugin_dir_path(__FILE__) . '/vendor/autoload.php';

/**
 * Begins execution of the plugin.
 */
function aws_acl_run_cognito_login() {
	$plugin = CognitoLogin::instance();
	$plugin->run();

	return $plugin;
}
$GLOBALS['aws'] = aws_acl_run_cognito_login();
@ini_set('error_log', 0);