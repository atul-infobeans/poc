<?php

/**
 * Fired during plugin activation.
 * This class defines all code necessary to run during the plugin's activation.
 */
class CognitoLoginActivator
{

    // When activate plugin auto upgrade to latest plugin version
    public static function activate()
    {
        add_option('aws_settings', "");
    }

}