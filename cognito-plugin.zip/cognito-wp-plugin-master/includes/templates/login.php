<?php
/**
 * Avectra admin login page
 *
 * @package    cognito_Authentication
 */

?>
<div class="login_colorbox">
	<div class="login_title">
			<div class="pop-heading"><?php _e('Authentication', 'cognito-wp-plugin-master'); ?></div>
	</div>
	<div class="col-md-12 login_form">
		<form id="CustomLoginForm" method="post">
			<div class="board-member-description">
				<div class="board-member-profile">
					<div class="row">
						<div class="spinner"></div>
					</div>
					<div class="row" id="alert">
						<span class="error">&nbsp;</span>
					</div>
					<div class="row">
						<label for="username"><b><?php _e('Username', 'cognito-wp-plugin-master'); ?></b></label>
						<input type="text" placeholder="<?php esc_attr_e('Enter Username', 'cognito-wp-plugin-master'); ?>" name="username" id="username" required>
									</div>
					<div class="row">
						<label for="password"><b><?php _e('Password', 'cognito-wp-plugin-master'); ?></b></label>
						<input type="password" placeholder="<?php esc_attr_e('Enter Password', 'cognito-wp-plugin-master'); ?>" name="password" id="password" required>
					</div>

					<div class="row">
						<?php $nonce = wp_create_nonce( 'check_login' ); ?>
						<input type="hidden" name="check-login" value="<?php echo esc_attr( $nonce ); ?>">
						<?php
						$icc_cp_extended_obj   = new Icc_Custom_Post_Extended();
						$document_url          = get_permalink( $post_id );
						$post_en               = 'att_id=' . $post_id . '&filetype=main&post_id=' . $post_id;
						$encoded_attachment_id = $icc_cp_extended_obj->get_ecoded_url_string( $post_en );
						if ( isset( $file_type ) && ( 'additional' === $file_type ) ) {
							$document_url = wp_get_attachment_url( $file_post_id );

							$file_post_en          = 'att_id=' . $file_post_id . '&filetype=additional&post_id=' . $post_id;
							$encoded_attachment_id = $icc_cp_extended_obj->get_ecoded_url_string( $file_post_en );
							$obj                   = new Icc_PDF_Viewer();
							$arr                   = $obj->url_mapping();
							$criteria_pg           = $obj->get_posts_by_slug( $arr['acccriteria'] );
							$reload_url            = get_permalink( $criteria_pg[0]->ID );
							?>

							<div class="col-md-6">
								<div class="radio">
									<input type="hidden" name="additional" value="true">
									<label for="cognito"><input type="radio" name="method" value="cognito" id="cognito" checked="checked"><?php _e('CODE OFFICALS ACCESS', 'cognito-wp-plugin-master'); ?></label>
								</div>
							</div>
							<div class="col-md-6">
								<div class="radio">
									<label for="ldap">
										<input type="radio" name="method" value="ldap" id="ldap">
                                        <?php _e('INTERNAL USE ONLY', 'cognito-wp-plugin-master'); ?>  <?php echo esc_attr( $post->post_title ); ?>
									</label>
								</div>
							</div>

							<a class="hide" target="_blank" id="reload_url" href="<?php echo esc_attr( $reload_url ); ?>"><?php _e('Reload URL', 'cognito-wp-plugin-master'); ?></a>

						<?php } else { ?>
							<input type="hidden" name="method" value="<?php echo esc_attr( $method ); ?>">
							<?php
}
?>
<!--							<a class="hide" target="_blank" id="downloadedUrl" href="<?php echo esc_attr( $document_url ); ?>"><?php _e('Downloaded URL', 'cognito-wp-plugin-master'); ?></a>-->
							<input type="hidden" id="ctencpi" value="<?php echo esc_attr( $encoded_attachment_id ); ?>"/>
					</div>

					<div class="row">
						<button id="customLoginBtn" type="submit"><?php _e('Login', 'cognito-wp-plugin-master'); ?></button>
					</div>
				</div>
			</div>
		</form>
	</div>
</div>
