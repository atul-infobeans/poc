<?php
/**
 * Avectra admin login page
 *
 * @package    Cognito_Authentication
 */

 wp_enqueue_script(
	'tooltipster-script',
	'https://cdnjs.cloudflare.com/ajax/libs/tooltipster/3.3.0/js/jquery.tooltipster.min.js',
	array( 'jquery' ),
	'',
	true
);
wp_enqueue_style(
	'toltipster-style',
	'https://cdnjs.cloudflare.com/ajax/libs/tooltipster/3.3.0/css/tooltipster.css',
	'',
	''
);
wp_enqueue_script(
	'bootstrap-bundle-js',
	'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js',
	array( 'jquery' ),
	'4.3.1',
	true
);
wp_enqueue_style(
	'auth-style',
	get_stylesheet_directory_uri() . '/css/pages/auth-button.css',
	'',
	''
);
wp_enqueue_script(
	'auth-js',
	get_stylesheet_directory_uri() . '/js/pages/auth-button.js',
	'',
	'',
	true
);

$post             = get_post( $post_id );
$document_url     = 'javascript:;';
$string_to_encode = 'postid=' . $post->ID . '&posttype=replisting&filename=directoryvalid';

$icc_cp_extended_obj = new Icc_Custom_Post_Extended();

$encoded_string      = $icc_cp_extended_obj->get_ecoded_url_string( $string_to_encode );
?>
<div class="col-md-12 authentication-btn">
	<div class="col-md-4 col-sm-4 pad-0">
			<a
				class="btn btn-primary btn-login1"
				rel="open_ajax"
				data-placement="bottom"
				href="<?php echo esc_attr( admin_url( 'admin-ajax.php' ) ); ?>?action=customLogin&key=<?php echo esc_attr( $encoded_string ); ?>&method=external"
				cbox-width="500px"
				cbox-heignt="500px">
                <?php _e('EXTERNAL ACCESS', 'cognito-wp-plugin-master'); ?>
			</a>
	</div>
	<div class="col-md-4 col-sm-4 pad-0">
		<?php if ( isset( $_SESSION['ind_token'] ) && ( 'ldap' === $_SESSION['authentication_ldap'] ) ) { ?>
			<a class="btn btn-primary report_file_download" href="<?php echo esc_html( $document_url ); ?>" cbox-width="500px" cbox-heignt="500px"><?php _e('INTERNAL USE ONLY', 'cognito-wp-plugin-master'); ?></a>
		<?php } else { ?>
			<a class="btn btn-primary" rel="open_ajax" href="<?php echo esc_attr( admin_url( 'admin-ajax.php' ) ); ?>?action=customLogin&key=<?php echo esc_attr( $encoded_string ); ?>&method=ldap" cbox-width="500px" cbox-heignt="500px"><?php _e('INTERNAL USE ONLY', 'cognito-wp-plugin-master'); ?></a>
		<?php } ?>
	</div>
</div>
