<?php
/**
 * Avectra admin login page
 *
 * @package    cognito_Authentication
 */

wp_enqueue_script( "tooltipster-script", "https://cdnjs.cloudflare.com/ajax/libs/tooltipster/3.3.0/js/jquery.tooltipster.min.js", array('jquery'), '', true );
wp_enqueue_style("toltipster-style", "https://cdnjs.cloudflare.com/ajax/libs/tooltipster/3.3.0/css/tooltipster.css", "", "");
wp_enqueue_script( 'bootstrap-bundle-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js', array('jquery'), '4.3.1', true );
wp_enqueue_style("auth-style", get_stylesheet_directory_uri().'/css/pages/auth-button.css', "", "");
wp_enqueue_script("auth-js", get_stylesheet_directory_uri().'/js/pages/auth-button.js', "", "", true);


	$post       = get_post( $post_id );
	$store_link = get_post_meta( $post_id, 'store_link', true );


$post       = get_post( $post_id );
$store_link = get_post_meta( $post_id, 'store_link', true );

$criteria_data = get_post_meta( $post->ID );

$icc_cp_extended_obj = new Icc_Custom_Post_Extended();
$string_to_encode = 'postid=' . $post->ID . '&posttype=' . $post->post_type . '&filename=' . basename( get_attached_file( $file_post_id ), '.pdf' ) . '&fileid=' . $file_post_id;
$encoded_string   = $icc_cp_extended_obj->get_ecoded_url_string( $string_to_encode );

$document_url = 'javascript:;';

	$file_access = get_post_meta( $post->ID, 'file_access', true );
if ( 'acccriteria' === $post->post_type && isset( $file_access ) && 'protected' === strtolower( $file_access ) ) {
	?>

    <!-- Tooltip content -->
    <div class="tooltip_templates">
    <div id="tooltip_content">
        <div>
            <?php _e('The', 'cognito-wp-plugin-master'); ?> <span class="tooltip_span"><?php _e('Primary Contact', 'cognito-wp-plugin-master'); ?></span><?php _e(' of a Governmental Organization may log in using this option to view this Acceptance
        Criteria. To log in, input your ', 'cognito-wp-plugin-master'); ?><span class="tooltip_span"><?php _e('ICC Member ID', 'cognito-wp-plugin-master'); ?></span> <?php _e('and', 'cognito-wp-plugin-master'); ?> <span class="tooltip_span"><?php _e('Password.', 'cognito-wp-plugin-master'); ?></span>
        </div>
        <div style="margin-top:15px">
            <?php _e('Please reach out to our Connect+ Customer Care Team at', 'cognito-wp-plugin-master'); ?> <br><?php _e('(800) 423-6587 if you need help with this option.', 'cognito-wp-plugin-master'); ?>
        </div>
    </div>
    </div>
    <!-- Tooltip Content End -->

	<div class="col-md-12 authentication-btn">
		<div class="col-md-4 col-sm-4 pad-0">

            <?php if (isset($_SESSION['ind_token']) && ('cognito' === $_SESSION['authentication_cognito'])) { ?>
                <a
                        class="btn btn-primary btn-login report_file_download"
                        data-toggle="tooltip"
                        data-placement="bottom"
                        data-tooltip-content="#tooltip_content"
                        href="<?php echo esc_html($document_url); ?>"
                        cbox-width="500px"
                        cbox-heignt="500px"
                >   <?php _e('CODE OFFICIALS ACCESS', 'cognito-wp-plugin-master'); ?>
                </a>
            <?php } else { ?>
                <a
                        class="btn btn-primary btn-login"
                        rel="open_ajax"
                        data-toggle="tooltip"
                        data-placement="bottom"
                        data-tooltip-content="#tooltip_content"
                        href="<?php echo esc_attr(admin_url('admin-ajax.php')); ?>?action=customLogin&key=<?php echo esc_attr($encoded_string); ?>&method=cognito"
                        cbox-width="500px"
                        cbox-heignt="500px"
                >   <?php _e('CODE OFFICIALS ACCESS', 'cognito-wp-plugin-master'); ?>
                </a>
            <?php } ?>
		</div>

		<div class="col-md-4 col-sm-4 pad-0">
		<?php if ( isset( $_SESSION['ind_token'] ) && ( 'ldap' === $_SESSION['authentication_ldap'] ) ) { ?>
					<a class="btn btn-primary report_file_download" href="<?php echo esc_html( $document_url ); ?>" cbox-width="500px" cbox-heignt="500px">INTERNAL USE ONLY  <?php echo esc_attr( $post->post_title ); ?></a>
			<?php } else { ?>
				<a class="btn btn-primary" rel="open_ajax" href="<?php echo esc_attr( admin_url( 'admin-ajax.php' ) ); ?>?action=customLogin&key=<?php echo esc_attr( $encoded_string ); ?>&method=ldap" cbox-width="500px" cbox-heignt="500px">INTERNAL USE ONLY  <?php echo esc_attr( $post->post_title ); ?></a>
			<?php } ?>
		</div>
		<div class="col-md-4 col-sm-4 pad-0">
		<?php if ( ! empty( $store_link ) ) { ?>
			<a target="_blank" class="btn btn-primary" href="<?php echo esc_attr( $store_link ); ?>">Purchase <?php echo esc_attr( $post->post_title ); ?></a>
		</div>
	</div>
			<?php
}
}
?>