<?php

/**
 * The file that defines the core plugin class
 *
 * A class definition that includes attributes and functions used across both the
 * public-facing side of the site and the admin area.
 *
 * This is used to define admin-specific hooks, and
 * public-facing site hooks.
 *
 * Also maintains the unique identifier of this plugin as well as the current
 * version of the plugin.
 */
class CognitoLogin
{

    //Public class where all hooks are added
    protected static $_instance = null;

    //The loader that's responsible for maintaining and registering all hooks that power the plugin.
    public $aws;

    //The unique identifier of this plugin.
    protected $loader;

    //The current version of the plugin.
    protected $plugin_name;

    //array of plugin settings
    protected $version;

    //Plugin Instance
    protected $opts;

    //The plugin text domain for translations, used to uniquely identify this plugin.
    protected $text_domain;

    //The Cognito Authenticator
    private $icc_cognito;

    //All overwritten WP Pluggables
    private $wp_pluggables;

    //Public Loader
    private $publicLoader;
    
    //wploader Loader
    private $wpLoader;

    //load files, login form, auth buttons.
    protected $icc_file_auth;

    //Main aws Instance, ensures only one instance of WSI is loaded or can be loaded.

    /**
     * Define the core functionality of the plugin.
     * Set the plugin name and the plugin version that can be used throughout the plugin.
     * Load the dependencies, define the locale, and set the hooks for the admin area and
     * the public-facing side of the site.
     */
    public function __construct()
    {

        $this->load_dependencies();

        $this->plugin_name = 'cognito-login';
        $this->text_domain = 'aws';
        $this->version = AWS_VERSION_LOGIN;
        $this->opts = get_option('aws_settings');

        $this->define_admin_hooks();

    }

    //Cloning is forbidden.

    /**
     * Load the required dependencies for this plugin.
     * Include the following files that make up the plugin:
     * - CognitoLoginLoader. Orchestrates the hooks of the plugin.
     * - CognitoLoginAdmin. Defines all hooks for the admin area.
     * - CognitoLoginPublic. Defines all hooks for the public side of the site.
     * Create an instance of the loader which will be used to register the hooks
     * with WordPress.
     */
    private function load_dependencies()
    {

        //Includes
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/Services/Loader/class-cognito-login-loader.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/Services/Cognito/class-cognito-processor.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/Services/WordPress/class-cognito-wordpress-loader.php';

        //Admin
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-cognito-login-admin.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'admin/class-cognito-login-settings.php';

        //Public
        require_once plugin_dir_path(dirname(__FILE__)) . 'public/Services/Loader/class-cognito-login-public.php';

        /**
         * login template, auth button, file render.
         */
        require_once plugin_dir_path(dirname(__FILE__)) .  'includes/class-icc-file-authentication.php';

        $this->loader = new CognitoLoginLoader();
        $this->publicLoader = new CognitoLoginPublic();
        $this->wpLoader = new CognitoWordpressLoader();
        $this->icc_cognito = new CognitoAuthenticator();
        $this->icc_file_auth = new Icc_File_Authentication();

    }


    //Unserializing instances of this class is forbidden.

    /**
     * Register all of the hooks related to the admin area functionality
     * of the plugin.
     */
    private function define_admin_hooks()
    {

        $plugin_admin = new CognitoLoginAdmin($this->get_plugin_name(), $this->get_version());

        $this->loader->add_action('admin_menu', $plugin_admin, 'add_menu_items');
        $this->loader->add_action('admin_init', $plugin_admin, 'create_settings');
        $this->loader->add_action('admin_enqueue_scripts', $plugin_admin, 'enqueue_admin_styles');
    }

    //Auto-load in-accessible properties on demand.

    /**
     * The name of the plugin used to uniquely identify it within the context of
     * WordPress and to define internationalization functionality.
     */
    public function get_plugin_name()
    {
        return $this->plugin_name;
    }

    /**
     * Retrieve the version number of the plugin.
     */
    public function get_version()
    {
        return $this->version;
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     * of the plugin.
     */

    public static function instance()
    {
        if (is_null(self::$_instance)) {
            self::$_instance = new self();
        }
        return self::$_instance;
    }

    public function __clone()
    {
        _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'wsi'), '2.1');
    }

    public function __wakeup()
    {
        _doing_it_wrong(__FUNCTION__, __('Cheatin&#8217; huh?', 'wsi'), '2.1');
    }

    /**
     * @param $key
     * @return mixed
     */
    public function __get($key)
    {
        if (in_array($key, ['payment_gateways', 'shipping', 'mailer', 'checkout'])) {
            return $this->$key();
        }
    }

    /**
     * Run the loader to execute all of the hooks with WordPress.
     */
    public function run()
    {
        $this->loader->run();
    }

    /**
     * The reference to the class that orchestrates the hooks with the plugin.
     */
    public function get_loader()
    {
        return $this->loader;
    }

}
