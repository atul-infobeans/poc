<?php
/**
 * Class for File Accessibility
 *
 * @package    cognito_Authentication
 */

/**
 * Description of class-icc-file-authentication
 *
 * @author khushbuajmera
 */
if(!class_exists('Icc_file_authentication')){
class Icc_File_Authentication {

	/**
	 * Constructor function
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( $this, 'class_initialization' ) );
		$this->login_add_actions();
	}

	/**
	 * Function to initialize admin listing class
	 */
	public function class_initialization() {

		/* set ajax url */
		wp_enqueue_script( 'make-custom-ajax', plugins_url() . '/cognito-wp-plugin-master/js/custom.js', array( 'jquery' ), '1.0.0' );
		/* set ajax url */
		wp_localize_script( 'make-custom-ajax', 'MBAjax', array( 'ajaxurl' => admin_url( 'admin-ajax.php' ) ) );
		add_shortcode( 'AUTHENTICATION_BUTTONS', array( $this, 'render_authentication_button' ) );
		add_shortcode( 'LISTING_AUTHENTICATION_BUTTONS', array( $this, 'render_listing_authentication_button' ) );

	}

	/**
	 * Function to add actions
	 */
	public function login_add_actions() {
		add_action( 'wp_ajax_check_login', array( $this, 'check_login' ) );
		add_action( 'wp_ajax_nopriv_check_login', array( $this, 'check_login' ) );

		add_action( 'init', array( $this, 'authentication_start_session' ), 1 );

		add_action( 'wp_ajax_customLogin', array( $this, 'custom_login' ) );
		add_action( 'wp_ajax_nopriv_customLogin', array( $this, 'custom_login' ) );

		add_action( 'wp_ajax_setPdfSession', array( $this, 'set_pdf_session' ) );
		add_action( 'wp_ajax_nopriv_setPdfSession', array( $this, 'set_pdf_session' ) );

	}

	/**
	 * This function is display login box
	 *
	 * @SuppressWarnings("unused")
	 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
	 */
	public function custom_login() {
		$key          = '';
		$method       = '';
		$key          = get_request_data( 'GET', 'key' );
		$extended     = new Icc_Custom_Post_Extended();
		$arr          = $extended->get_decoded_url_string( $key );
		$post_id      = ( isset( $arr['postid'] ) ) ? $arr['postid'] : '';
		$post         = get_post( $post_id );
		$file_post_id = ( isset( $arr['fileid'] ) ) ? $arr['fileid'] : '';
		$file_type    = ( isset( $arr['file_type'] ) ) ? $arr['file_type'] : '';
		$method       = get_request_data( 'GET', 'method' );

		require_once plugin_dir_path( __FILE__ ) . 'templates/login.php';
		wp_die();
	}

	/**
	 * This function is used to start session
	 */
	public function authentication_start_session() {
		if ( ! session_id() ) {
			session_start();
		}
	}

	/**
	 * This function is used for user authentication
	 */
	public function check_login() {

		if ( isset( $_POST['check-login'] ) && wp_verify_nonce( sanitize_key( $_POST['check-login'] ), 'check_login' ) ) { // Input var okay.
			$data = filter_var_array( $_POST );
			if ( isset( $data ) ) {
				if ( empty( $data['username'] ) && empty( $data['password'] ) ) {
					echo wp_json_encode(
						[
							'success' => false,
							'msg'     => 'Please enter username and password.',
						]
					);
					wp_die();
				}
				if ( 'cognito' === $data['method'] ) {
					$this->cognito_authentication( $data );
				} elseif ( 'external' === $data['method'] ) {
					$this->external_authentication( $data );
				} else {
					$this->ldap_authentication( $data );
				}
			}
		} else {
			echo wp_json_encode(
				[
					'success' => false,
					'msg'     => 'Sorry, your nonce did not verify.',
				]
			);
			wp_die();
		}
		echo wp_json_encode(
			[
				'success' => false,
				'msg'     => 'Unable to Login.',
			]
		);
		wp_die();
	}

	/**
	 * This function is used for cognito authentication
	 *
	 * @param type $data <Array>.
	 */
	public function cognito_authentication( $data ) {
		$cognitoAuthenticator = new \CognitoAuthenticator();
    	$user = $cognitoAuthenticator->authViaCognito($data['username'], $data['password']);
		if ( ! empty( $user ) ) {
			switch ( $user['status'] ) {

				case 'success':
					unset($_SESSION['authentication_external']);
					$_SESSION['authentication_cognito'] = 'cognito';
					$_SESSION['ind_token']            = $user['data']['aws_username'];
					$_SESSION['pdfview']              = 1;
					setcookie( 'pdfViewer', 'loggedin' ); // 60 seconds ( 1 minute) * 20 = 20 minutes
					$icc_cp_extended_obj = new Icc_Custom_Post_Extended();
					$file_post_de        = $icc_cp_extended_obj->get_decoded_url_string( $data['ctencpi'] );
					$file_post_id        = $file_post_de['att_id'];
					$document_url        = get_permalink( $file_post_de['post_id'] );
					if ( 'main' === $file_post_de['filetype'] ) {
						$document_url = get_permalink( $file_post_id );
					} else {
						$document_url = wp_get_attachment_url( $file_post_id );
					}

					echo wp_json_encode(
						[
							'success' => true,
							'msg'     => $user['message'],
							'doc_url' => $document_url,
						]
					);
					wp_die();
					break;

				default:
					echo wp_json_encode(
						[
							'success' => false,
							'msg'     => 'Unable to Login.',
						]
					);
					wp_die();
					break;
			}
		}
	}

	/**
	 * This function is used for abila authentication
	 *
	 * @param type $data <Array>.
	 */
	public function external_authentication( $data ) {
		unset( $_SESSION['authentication_ldap'], $_SESSION['authentication_cognito'], $_SESSION['ind_token'] );
		setcookie( 'pdfViewer', '', time() - 3600 );
		$query_array[] = [
			'key' => 'util_username',
			'value' => $data['username'],
			'compare' => '=',
		];
		$query_array[] = [
			'key' => 'util_password',
			'value' => $data['password'],
			'compare' => '=',
		];
		$args = array(
            'post_type' => 'acccriteria',
            'post_status' => 'publish',
            'lang' => '',
            'offset' => 0,
            'posts_per_page' => -1,
            'meta_query' => [
                $query_array,
            ],
		);
		$records = new WP_Query( $args );
		if ( $records->post_count) {
			$_SESSION['pdfview']                 = 1;
			$_SESSION['authentication_external'] = base64_encode( $data['username'] . '<==>' . $data['password'] );
			echo wp_json_encode(
				[
					'success' => true,
					'msg'     => 'Authenticated successfully!',
					'data'	=> new WP_Query( $args ),
					'doc_url' => '',
				]
			);	
		} else {
			echo wp_json_encode(
				[
					'success' => false,
					'msg'     => 'Invalid Username/Password',
				]
			);
		}
		wp_die();
	}

	/**
	 * This function is used for ldap authentication
	 *
	 * @param type $data <Array>.
	 */
	public function ldap_authentication( $data ) {

		$response = ldap_auth_signon( $data['username'], $data['password'] );
		if ( true === $response['success'] ) {
			unset($_SESSION['authentication_external']);
			$_SESSION['authentication_ldap'] = 'ldap';
			$_SESSION['ind_token']           = $response['user_data']['user_login'];
			$_SESSION['pdfview']             = 1;
			setcookie( 'pdfViewer', 'loggedin' ); // 60 seconds ( 1 minute) * 20 = 20 minutes
			$icc_cp_extended_obj = new Icc_Custom_Post_Extended();
			$file_post_de        = $icc_cp_extended_obj->get_decoded_url_string( $data['ctencpi'] );
			$file_post_id        = $file_post_de['att_id'];
			$document_url        = get_permalink( $file_post_de['post_id'] );
			if ( 'main' === $file_post_de['filetype'] ) {
				$document_url = get_permalink( $file_post_id );
			} else {
				$document_url = wp_get_attachment_url( $file_post_id );
			}
			$response['doc_url'] = $document_url;
		}
		echo wp_json_encode( $response );
		wp_die();
	}

	/**
	 * Function is used to render Important Notices
	 *
	 * @param type $atts <Array>.
	 * @SuppressWarnings("unused")
	 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
	 */
	public function render_authentication_button( $atts ) {
		ob_start();
		$post_id      = $atts['id'];
		$file_post_id = $atts['file_post_id'];
		include plugin_dir_path( __FILE__ ) . 'templates/authentication-button.php';
		$return_string = ob_get_contents();
		ob_end_clean();
		return $return_string;
	}

	/**
	 * Function is used to render auth button page on listing
	 *
	 * @param type $atts <Array>.
	 * @SuppressWarnings("unused")
	 * @SuppressWarnings(PHPMD.UnusedFormalParameter)
	 */
	public function render_listing_authentication_button( $atts ) {
		ob_start();
		$post_id      = $atts['id'];
		$file_post_id = $atts['file_post_id'];
		include plugin_dir_path( __FILE__ ) . 'templates/authentication-button-listing.php';
		$return_string = ob_get_contents();
		ob_end_clean();
		return $return_string;
	}

	/**
	 * This function is used to get page title
	 */
	public function document_title() {
		$key      = get_request_data( 'GET', 'key' );
		$extended = new Icc_Custom_Post_Extended();
		$arr      = $extended->get_decoded_url_string( $key );
		$post_id  = ( isset( $arr['post_id'] ) ) ? $arr['post_id'] : '';
		return get_post_meta( $post_id, 'criteria_title', true );
	}

	/**
	 * This function is used to set pdf session
	 */
	public function set_pdf_session() {
		$_SESSION['pdfview'] = 1;
		echo 'set';
		wp_die();
	}
}
}