<?php

use Aws\CognitoIdentityProvider\Exception\CognitoIdentityProviderException;
use ICC\Component\Cognito\ICCCognitoCache;
use ICC\Component\Cognito\ICCCognitoClient;
use ICC\Component\Cognito\ICCCognitoContainer;
use ICC\Component\Cognito\ICCCognitoCookieClient;
use pmill\AwsCognito\Exception\ChallengeException;
use pmill\AwsCognito\Exception\CognitoResponseException;
use pmill\AwsCognito\Exception\TokenExpiryException;
use pmill\AwsCognito\Exception\TokenVerificationException;
use Symfony\Component\HttpClient\CurlHttpClient;

class CognitoAuthenticator
{

    /**
     * @var ICCCognitoClient
     */
    private $cognitoClient;

    /**
     * @var $cognitoSSOClient
     */
    private $cognitoSSOClient;

    /**
     * @var ICCCognitoCookieClient
     */
    private $cognitoCookieClient;

    /**
     * @var cognitoContainer
     */
    private $cognitoContainer;

    /**
     * @var $awsSettings ;
     */
    private $awsSettings;
    private $local_settings;
    /**
     * @var @wpUserAuthentication
     */
    private $wpUserAuthentication;

    public function __construct()
    {
        $this->awsSettings = get_option('aws_settings');
        if (!empty ($this->awsSettings)) {
            //!!! TODO: Remove those before going to PROD !!//
            $this->local_settings = ['verify_peer' => 0, 'verify_host' => 0];
            //!!! TODO: One client for SSO, One client for basic-auth !!//
            $this->cognitoClient = new ICCCognitoClient($this->awsSettings['aws_id'], $this->awsSettings['aws_secret'], $this->awsSettings['aws_client_id'], $this->awsSettings['aws_client_secret'], $this->awsSettings['aws_region'], $this->awsSettings['aws_user_pool_id']);
            $this->cognitoSSOClient = new ICCCognitoClient($this->awsSettings['aws_id'], $this->awsSettings['aws_secret'], $this->awsSettings['aws_client_id'], $this->awsSettings['aws_client_secret'], $this->awsSettings['aws_region'], $this->awsSettings['aws_user_pool_id']);
            $this->cognitoContainer = new ICCCognitoContainer(new ICCCognitoCache(), $this->cognitoSSOClient, $this->awsSettings['sso_login_portal'], $this->awsSettings['cognito_token'], $this->local_settings);
            $this->cognitoCookieClient = new ICCCognitoCookieClient($this->cognitoClient, $this->cognitoContainer, $this->awsSettings['cookie_domain'], "3000", 1);
            $this->wpUserAuthentication = new CognitoWordpressAuthentication();

            /** Disable all action to logged in admin without cognito */
            //Actions
            //add_action('after_setup_theme', [$this, 'authenticateByCookie']);
            //add_action('wp_logout', [$this, 'destroyCookies'], 10);
            //add_action('wp_authenticate', [$this, 'authViaEmail'], 10, 2); //ignored
            //add_action('user_register', [$this, 'registerUserInCognito'], 10, 1);
            //add_action('lostpassword_post', [$this, 'resetPassword'], 10);
            /** END */
        }
    }

    /**
     * @param $username
     * @param $password
     * @throws ChallengeException
     * @throws TokenExpiryException
     * @throws TokenVerificationException
     */
    public function authViaEmail($username, $password)
    {
        //Validate Math Captcha
        if (!empty ($username) || !empty($password)):
            try {
                $userDetails = $this->formatAndReturnAWSUser("email", $username);
            } catch (Exception $e) {
                $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                $wpError = new WP_Error();
                $wpError->add('broke', $errorMessage);
            }
            if (!empty($userDetails) && is_array($userDetails) && empty($userDetails['error'])) {
                $cognitoUsername = $userDetails['aws_username'];
                $userGivenName = $userDetails['given_name'];
                $userFamilyName = $userDetails['family_name'];
                $userEmail = $userDetails['email'];

                try {
                    $response = $this->cognitoCookieClient->authenticateAndCreateCookie($username, $password);
                } catch (Exception $e) {
                    $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                    $wpError = new WP_Error();
                    $wpError->add('broke', $errorMessage);
                    wp_send_json_error($errorMessage);
                }
                if (isset($response)) {
                    //If the user is not found in WP's local DB, create the user.
                    if (!get_user_by('email', $userEmail)) {
                        $this->wpUserAuthentication->createWPUser($cognitoUsername, $userEmail, $userGivenName, $userFamilyName, ["CognitoUser" => true]);
                    }
                    $this->wpUserAuthentication->loginWpUser($userEmail);
                }
            } elseif (!empty($userDetails['error'])) {
                wp_send_json_error($userDetails['error']);
            }
        endif;
    }


    /**
     * @param $username
     * @param $password
     * @throws ChallengeException
     * @throws TokenExpiryException
     * @throws TokenVerificationException
     */
    public function authViaCognito($username, $password)
    {
        //Validate Math Captcha
        if (!empty ($username) || !empty($password)):
            try {
                $userDetails = $this->formatAndReturnAWSUser("email", $username);
            } catch (Exception $e) {
               return $response = array(
                'msg' => "Unable to Login.",
                'success' => false
                );
            }
            if (!empty($userDetails) && is_array($userDetails) && empty($userDetails['error'])) {
                $cognitoUsername = $userDetails['aws_username'];
                $userGivenName = $userDetails['given_name'];
                $userFamilyName = $userDetails['family_name'];
                $userEmail = $userDetails['email'];

                try {
                    $response = $this->cognitoCookieClient->authenticateAndCreateCookie($username, $password);
                } catch (Exception $e) {
                    return $response = array(
                        'msg' => "Unable to Login.",
                        'success' => false
                        );
                }
                if (isset($response)) {
                    $login_response = $this->wpUserAuthentication->cognitoUserLogin($userEmail, $userDetails);
                    return $login_response;
                }
            } elseif (!empty($userDetails['error'])) {
                return $response = array(
                    'msg' => "Unable to Login.",
                    'success' => false
                    );
            }
        endif;
    }

    /**
     * @param $method
     * @param string $username
     * @param string $token
     * @return array
     * @throws TokenExpiryException
     * @throws TokenVerificationException
     */

    public function formatAndReturnAWSUser($method, $username = null, $token = null)
    {
        if ($method === 'email') {
            try {
                $raw_result = $this->cognitoClient->getUser($username)['UserAttributes'];
            } catch (Exception $e) {
                return $response = array(
                    'msg' => "Unable to Login.",
                    'success' => false
                    );
            }
        } elseif ($method === 'token') {
            try {
                $raw_result = $result = $this->cognitoClient->getUserByToken($token)['UserAttributes'];
            } catch (Exception $e) {
                return $response = array(
                    'msg' => "Unable to Login.",
                    'success' => false
                    );
            }
        }
        $data = [];
        if (empty($wpError) && !empty($raw_result) && is_array($raw_result)) {
//            //Get All Keys from the possibly chaotic AWS User Object;
            foreach ($raw_result as $key => $sub_array) {
                switch ($sub_array['Name']) {
                    case 'sub':
                        $data['aws_username'] = $sub_array['Value'];
                        break;
                    case 'email':
                        $data['email'] = $sub_array['Value'];
                        break;
                    case 'email_confirmed':
                        $data['email_confirmed'] = $sub_array['Value'];
                        break;
                    case 'given_name':
                        $data['given_name'] = $sub_array['Value'];
                        break;
                    case 'family_name':
                        $data['family_name'] = $sub_array['Value'];
                        break;
                    case 'av_record':
                        $data['av_record'] = $sub_array['Value'];
                }
            }
        } elseif (!empty($wpError)) {
            $data['error'] = $errorMessage;
        }
        return $data;
    }

    /**
     * @param $token
     * @throws TokenExpiryException
     * @throws TokenVerificationException
     */
    public function authViaTokenAndKeepTokenAlive($token)
    {
        try {
            $tokenChecker = $this->cognitoCookieClient->authenticateByToken($token);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            wp_send_json_error($errorMessage);
            $wpError = new WP_Error();
            $wpError->add('broke', $errorMessage);
        }

        if (!is_user_logged_in()) {
            if ($tokenChecker === true) {
                try {
                    $result = $this->cognitoClient->getUserByToken($token);
                    $cognitoUsername = $result['UserAttributes'][0]['Value'];
                    $userEmail = $result['UserAttributes'][5]['Value'];

                } catch (Exception $e) {
                    $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                    $wpError = new WP_Error();
                    $wpError->add('broke', $errorMessage);
                    wp_send_json_error($errorMessage);
                }
                if (isset($userEmail)) {
                    $this->wpUserAuthentication->createWPUser($cognitoUsername, $userEmail);
                }
                $this->wpUserAuthentication->loginWpUser($userEmail);
            }
        }
    }

    /**
     * @param null $token
     * @throws TokenExpiryException
     * @throws TokenVerificationException
     */
    public function authenticateByCookie($token = null)
    {
        $cookieChecker = $this->cognitoCookieClient->authenticateByCookie();
        //dana == false
        //nstankov === true
        if (!is_user_logged_in() && $cookieChecker === true) {
            try {
                if (!$token) {
                    $accessTokenCookieName = "IccCookie_x";
                    $token = $_COOKIE[$accessTokenCookieName];
                }
                $formattedCognitoUser = $this->formatAndReturnAWSUser("token", null, $token);
                $userAWSUser = $formattedCognitoUser['aws_username'];
                $userEmail = $formattedCognitoUser['email'];
                $userGivenName = $formattedCognitoUser['given_name'];
                $userFamilyName = $formattedCognitoUser['family_name'];
            } catch (Exception $e) {
                $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                $wpError = new WP_Error();
                $wpError->add('broke', $errorMessage);
                wp_send_json_error($errorMessage);
            }
            if (isset($userEmail) && !get_user_by('email', $userEmail)) {
                $this->wpUserAuthentication->createWPUser($userAWSUser, $userEmail, $userGivenName, $userFamilyName, ["CognitoUser" => true]);
            }
            $this->wpUserAuthentication->loginWpUser($userEmail);
        } elseif (is_user_logged_in() && $cookieChecker === false) {
            //Logout user;
            if ($this->awsSettings['cognito_core_wp_auth_mode'] === "1") {
                do_action('wp_logout');
                $this->wpUserAuthentication->logOutUserExtraSecurity();
            }
        }
    }

    /**
     * Not live in component yet.
     * Cookie Monster Ate the Cookie
     */
    public
    function destroyCookies($userLogin = null)
    {
        if (empty($userLogin)) {
            $userObject = wp_get_current_user();

            if (is_object($userObject)) {
                $userLogin = $userObject->data->user_email;
            }
        }
        if (!empty ($userLogin)) {
            try {
                $response = $this->cognitoCookieClient->globalSignOut($userLogin);
            } catch (Exception $e) {
                $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                wp_send_json_error($errorMessage);
                $wpError = new WP_Error();
                $wpError->add('broke', $errorMessage);
            }
        }
        $this->wpUserAuthentication->logOutUserExtraSecurity();
    }

    /**
     * @param null $user_id
     * @param null $email
     * @param $password
     * @param null $user_given_name
     * @param null $user_family_name
     * @param null $user_security_question
     * @param null $user_security_answer
     */
    public function registerUserInCognito($user_id = null, $email = null, $password = null, $user_given_name = null, $user_family_name = null, $user_security_question = null, $user_security_answer = null)
    {
        if (!empty($user_id)) {
            return;
        }
        $inputs = [$user_id, $email, $password, $user_given_name, $user_family_name, $user_security_question, $user_security_answer];
        if ($this->emptyChecker($inputs)) {
            if (!empty($_POST)) {
                if (!empty($_POST['email'])) {
                    $email = $_POST['email'];
                } else {
                    $email = $_POST['user_email'];
                }
                $password = $_POST['password'];
                $user_given_name = $_POST['given_name'];
                $user_family_name = $_POST['family_name'];
                $user_security_question = $_POST['security_question'];
                $user_security_answer = $_POST['security_answer'];
            }
        }
        try {
            $response = $this->cognitoClient->registerUser(
                $email,
                $password,
                [
                    'email' => $email,
                    'given_name' => $user_given_name,
                    'family_name' => $user_family_name,
                    'custom:security_question' => $user_security_question,
                    'custom:security_answer' => $user_security_answer
                    /**
                     * More fields can be added here if they exist in the Cognito user pool attributes, and you know the proper key
                     */
                ]
            );
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            $wpError = new WP_Error();
            $wpError->add('broke', $errorMessage);
            wp_send_json_error($errorMessage);
        }
    }

    /**
     * @param array $inputs
     * @return bool
     */
    public function emptyChecker(array $inputs)
    {
        foreach ($inputs as $value) {
            if (!empty($value)) {
                return false;
            }
        }
        return true;
    }

    /**
     * @param $email
     * @return bool
     */
    public function resendRegistrationConfirmationCode($email)
    {
        try {
            $response = $this->cognitoClient->resendRegistrationConfirmationCode($email);
            return true;
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            wp_send_json_error($errorMessage);
            return $errorMessage;
        }
    }

    /**
     * @param null $user_id
     * @param null $email
     * @param null $password
     * @param null $user_given_name
     * @param null $user_family_name
     * @param null $user_security_question
     * @param null $user_security_answer
     * @param array $clientMetadata
     */
    public function registerUserWithMetadata($user_id = null, $email = null, $password = null, $user_given_name = null, $user_family_name = null, $user_security_question = null, $user_security_answer = null, array $clientMetadata = [])
    {
        if (!empty($user_id)) {
            return;
        }
        $inputs = [$user_id, $email, $password, $user_given_name, $user_family_name, $user_security_question, $user_security_answer, $clientMetadata];
        if ($this->emptyChecker($inputs)) {
            if (!empty($_POST)) {
                if (!empty($_POST['email'])) {
                    $email = $_POST['email'];
                } else {
                    $email = $_POST['user_email'];
                }
                $password = $_POST['password'];
                $user_given_name = $_POST['given_name'];
                $user_family_name = $_POST['family_name'];
                $user_security_question = $_POST['security_question'];
                $user_security_answer = $_POST['security_answer'];
                $clientMetadata = $_POST['client_metadata'];
            }
        }
        try {
            $response = $this->cognitoClient->registerUserWithMetadata(
                $email,
                $password,
                [
                    'email' => $email,
                    'given_name' => $user_given_name,
                    'family_name' => $user_family_name,
                    'custom:security_question' => $user_security_question,
                    'custom:security_answer' => $user_security_answer
                    /**
                     * More fields can be added here if they exist in the Cognito user pool attributes, and you know the proper key
                     */
                ],
                $clientMetadata
            );
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            $wpError = new WP_Error();
            $wpError->add('broke', $errorMessage);
            wp_send_json_error($errorMessage);
        }
    }

    /**
     * @param null $userEmail
     * @throws TokenExpiryException
     * @throws TokenVerificationException
     */

    public function resetPassword($userEmail = null)
    {
        $inputs = [$userEmail];
        if ($this->emptyChecker($inputs)) {
            if (!empty($_POST['user_login'])) {
                $userEmail = esc_sql($_POST['user_login']);
            }
        }
        if (!get_user_by('email', $userEmail)) {
            $cognitoUser = $this->formatAndReturnAWSUser("email", $userEmail);
            if (!empty($cognitoUser && !empty($cognitoUser['error']))) {
                $userAWSUser = $cognitoUser['aws_username'];
                $userEmail = $cognitoUser['email'];
                $userGivenName = $cognitoUser['given_name'];
                $userFamilyName = $cognitoUser['family_name'];
                try {
                    $this->wpUserAuthentication->createWPUser($userAWSUser, $userEmail, $userGivenName, $userFamilyName, ["CognitoUser" => true]);
                } catch (Exception $e) {
                    $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                    $wpError = new WP_Error();
                    $wpError->add('broke', $errorMessage);
                }
            } else {
                wp_send_json_error($cognitoUser['error']);
            }
        }

        $userObj = get_user_by('email', $userEmail);
        $userEmail = $userObj->data->user_email;
        try {
            $response = $this->cognitoClient->sendForgottenPasswordRequest($userEmail);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            $wpError = new WP_Error();
            $wpError->add('broke', $errorMessage);
            wp_send_json_error($errorMessage);
        }
    }

    /**
    * @param $callback
    * @param null $userEmail
    * @throws TokenExpiryException
    * @throws TokenVerificationException
    */
    public function resetPasswordWithMeta($callback, $userEmail = null)
    {
        $inputs = [$userEmail];
        if ($this->emptyChecker($inputs)) {
            if (!empty($_POST['user_login'])) {
                $userEmail = esc_sql($_POST['user_login']);
            }
        }
        if (!get_user_by('email', $userEmail)) {
            $cognitoUser = $this->formatAndReturnAWSUser("email", $userEmail);
            if (!empty($cognitoUser && !empty($cognitoUser['error']))) {
                $userAWSUser = $cognitoUser['aws_username'];
                $userEmail = $cognitoUser['email'];
                $userGivenName = $cognitoUser['given_name'];
                $userFamilyName = $cognitoUser['family_name'];
                try {
                    $this->wpUserAuthentication->createWPUser($userAWSUser, $userEmail, $userGivenName, $userFamilyName, ["CognitoUser" => true]);
                } catch (Exception $e) {
                    $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                    $wpError = new WP_Error();
                    $wpError->add('broke', $errorMessage);
                }
            } else {
                wp_send_json_error($cognitoUser['error']);
            }
        }

        $userObj = get_user_by('email', $userEmail);
        $userEmail = $userObj->data->user_email;
        try {
            $response = $this->cognitoClient->sendForgottenPasswordRequestWithMetadata($userEmail, $callback);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            $wpError = new WP_Error();
            $wpError->add('broke', $errorMessage);
            wp_send_json_error($errorMessage);
        }
    }

    /**
     * @param $verificationCode
     * @param $email
     * @return bool
     * @throws Exception
     */

    public function validateNewAccount($verificationCode, $email)
    {
        try {
            $response = $this->cognitoClient->confirmUserRegistration($verificationCode, $email);
            return true;
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            wp_send_json_error($errorMessage);
            return $errorMessage;
        }
    }

    /**
     * @param $verificationCode
     * @param $email
     * @param $password
     * @param array $callback
     * @return bool
     * @throws Exception
     */

    public function passwordResetValidation($verificationCode, $email, $password, $callback = [])
    {
        try {
            $response = $this->cognitoClient->resetPassword($verificationCode, $email, $password);
            return true;
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            wp_send_json_error($errorMessage);
            return $errorMessage;
        }
    }

    /**
     * @param $username
     * @param array $inputarr
     * @return mixed
     */
    public function updateUserAttributes($username, array $inputarr)
    {
        try {
            $response = $this->cognitoClient->updateUserAttributes($username, $inputarr);
        } catch (CognitoIdentityProviderException $e) {
            if (method_exists($e, "getAwsErrorMessage")) {
                $errorMessage = $e->getAwsErrorMessage();
            }
            wp_send_json_error($errorMessage);
            return $errorMessage;
        }
    }

}