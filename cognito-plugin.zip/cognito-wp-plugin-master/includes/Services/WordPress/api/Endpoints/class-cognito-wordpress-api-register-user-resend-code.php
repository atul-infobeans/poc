<?php

namespace ICC\API;

use pmill\AwsCognito\Exception\CognitoResponseException;
use WP_REST_Request;

final class registerUserResendConfirmation extends AbstractEndpoint
{

    protected $endpoint = '/register-resend-code';

    public function endpoint_args()
    {
        return [
            'email' => [
                'required' => true,
            ],
        ];
    }

    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'email' => $request->get_param('email'),
        ];
        return $this->validatePasswordReset($data);
    }

    public function validatePasswordReset($data)
    {
        try {
            $cognitoAuthenticator = new \CognitoAuthenticator();
            $cognitoAuthenticator->resendRegistrationConfirmationCode($data['email']);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            return wp_send_json_error($errorMessage);
        }
    }
}

registerUserResendConfirmation::init();