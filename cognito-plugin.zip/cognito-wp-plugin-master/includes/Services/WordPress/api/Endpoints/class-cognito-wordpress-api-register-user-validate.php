<?php

namespace ICC\API;

use pmill\AwsCognito\Exception\CognitoResponseException;
use WP_REST_Request;

final class registerUserValidate extends AbstractEndpoint
{

    protected $endpoint = '/register-user-validation';

    public function endpoint_args()
    {
        return [
            'verification_code' => [
                'required' => true,
            ],
            'user_login' => [
                'required' => true,
            ],
        ];
    }

    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'verification_code' => $request->get_param('verification_code'),
            'user_login' => $request->get_param('user_login'),
        ];
        return $this->validatePasswordReset($data);
    }

    public function validatePasswordReset($data)
    {
        try {
            $cognitoAuthenticator = new \CognitoAuthenticator();
            $cognitoAuthenticator->validateNewAccount($data['verification_code'], $data['user_login']);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            return wp_send_json_error($errorMessage);
        }
    }
}

registerUserValidate::init();