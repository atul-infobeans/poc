<?php

namespace ICC\API;

use pmill\AwsCognito\Exception\CognitoResponseException;
use WP_REST_Request;

final class LogIn extends AbstractEndpoint
{

    protected $endpoint = '/login';

    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'user_login' => $request->get_param('user_login'),
            'user_password' => $request->get_param('user_password'),
        ];
        return $this->loginViaApi($data);
    }

    public function loginViaApi($data)
    {
        try {
            $cognitoAuthenticator = new \CognitoAuthenticator();
            $cognitoAuthenticator->authViaEmail($data['user_login'], $data['user_password']);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            return wp_send_json_error($errorMessage);
        }
    }

    public function endpoint_args()
    {
        return [
            'user_login' => [
                'required' => true,
            ],
            'user_password' => [
                'required' => true,
            ],
        ];
    }
}

LogIn::init();