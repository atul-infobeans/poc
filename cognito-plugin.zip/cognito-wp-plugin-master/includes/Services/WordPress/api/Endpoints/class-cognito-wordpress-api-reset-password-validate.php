<?php

namespace ICC\API;

use pmill\AwsCognito\Exception\CognitoResponseException;
use WP_REST_Request;

final class resetPasswordValidation extends AbstractEndpoint
{
    protected $endpoint = '/reset-password-validation';

    public function endpoint_args()
    {
        return [
            'verification_code' => [
                'required' => true,
            ],
            'user_login' => [
                'required' => true,
            ],
            'user_password' => [
                'required' => true,
            ],
        ];
    }

    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'verification_code' => $request->get_param('verification_code'),
            'user_login' => $request->get_param('user_login'),
            'user_password' => $request->get_param('user_password'),
        ];
        return $this->validatePasswordReset($data);
    }

    public function validatePasswordReset($data)
    {
        try {
            $cognitoAuthenticator = new \CognitoAuthenticator();
            $cognitoAuthenticator->passwordResetValidation($data['verification_code'], $data['user_login'], $data['user_password']);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            return wp_send_json_error($errorMessage);
        }
    }
}

resetPasswordValidation::init();