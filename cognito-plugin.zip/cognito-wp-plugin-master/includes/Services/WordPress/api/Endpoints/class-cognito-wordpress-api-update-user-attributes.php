<?php
/**
 * This one is not in use yet, because it looks like no account has permissions to use it in AMAZON itself.
 */

namespace ICC\API;

use CognitoAuthenticator;
use Exception;
use WP_REST_Request;

final class updateUserAttributes extends AbstractEndpoint
{
    protected $endpoint = '/update-user-attributes';

    /**
     * @return array|\bool[][]|Array
     */
    public function endpoint_args()
    {
        return [
            'email' => [
                'required' => true,
            ],
            'metadataarray' => [
                'required' => true,
            ],
        ];
    }

    /**
     * @param WP_REST_Request $request
     * @return array|void
     */
    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'email' => $request->get_param('email'),
            'metadataarray' => $request->get_param('metadataarray'),
        ];
        return $this->updateUserMetaInCognito($data);
    }

    /**
     * @param array $data
     */
    public function updateUserMetaInCognito(array $data)
    {
        $email = $data['email'];
        $inputarr = (array) json_decode($data['metadataarray']);
        try {
            $cognitoAuthenticator = new CognitoAuthenticator();
            $response = $cognitoAuthenticator->updateUserAttributes($email, $inputarr);
            return wp_send_json_success($response);
        } catch (Exception $e) {
            if (method_exists($e, "getAwsErrorMessage")) {
                $errorMessage = $e->getAwsErrorMessage();
            } else {
                $errorMessage = "Unknown Error";
            }
            return wp_send_json_error($errorMessage);
        }
    }
}

updateUserAttributes::init();