<?php

namespace ICC\API;

use pmill\AwsCognito\Exception\CognitoResponseException;
use WP_REST_Request;

final class LogInViaToken extends AbstractEndpoint
{

    protected $endpoint = '/login-via-token';

    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'cognito_token' => $request->get_param('cognito_token'),
        ];
        return $this->loginViaApi($data);
    }

    public function loginViaApi($data)
    {
        try {
            $cognitoAuthenticator = new \CognitoAuthenticator();
            $cognitoAuthenticator->authViaTokenAndKeepTokenAlive($data['cognito_token']);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            return wp_send_json_error($errorMessage);
        }
    }

    public function endpoint_args()
    {
        return [
            'cognito_token' => [
                'required' => true,
            ]
        ];
    }
}

LogInViaToken::init();