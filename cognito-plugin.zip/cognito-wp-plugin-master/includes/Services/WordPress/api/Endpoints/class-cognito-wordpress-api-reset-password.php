<?php

namespace ICC\API;

use pmill\AwsCognito\Exception\CognitoResponseException;
use WP_REST_Request;

final class LogoutEndpoint extends AbstractEndpoint
{

    protected $endpoint = '/reset-password';

    public function endpoint_args()
    {
        return [
            'user_login' => [
                'required' => true,
            ],
        ];
    }

    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'user_login' => $request->get_param('user_login'),
        ];
        return $this->resetPWDViaApi($data);
    }

    public function resetPWDViaApi($data)
    {
        try {
            $cognitoAuthenticator = new \CognitoAuthenticator();
            $cognitoAuthenticator->resetPassword($data['user_login']);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            return wp_send_json_error($errorMessage);
        }
    }
}

LogoutEndpoint::init();