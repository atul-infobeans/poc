<?php

namespace ICC\API;

use pmill\AwsCognito\Exception\CognitoResponseException;
use WP_REST_Request;

final class registerUserWithMetadata extends AbstractEndpoint
{

    protected $endpoint = '/register-user-with-metadata';

    public function endpoint_args()
    {
        return [
            'password' => [
                'required' => true,
            ],
            'given_name' => [
                'required' => true,
            ],
            'family_name' => [
                'required' => true,
            ],
            'security_question' => [
                'required' => true,
            ],
            'security_answer' => [
                'required' => true,
            ],
            'email' => [
                'required' => true,
            ],
            'client_metadata' => [
                'type' => "json",
                'required' => true,
            ],
        ];
    }

    public function endpoint_callback(WP_REST_Request $request)
    {
        $data = [
            'password' => $request->get_param('password'),
            'given_name' => $request->get_param('given_name'),
            'family_name' => $request->get_param('family_name'),
            'security_question' => $request->get_param('security_question'),
            'security_answer' => $request->get_param('security_answer'),
            'email' => $request->get_param('email'),
            'client_metadata' => $request->get_param('client_metadata')
        ];
        return $this->validatePasswordReset($data);
    }

    public function validatePasswordReset($data)
    {
        try {
            $cognitoAuthenticator = new \CognitoAuthenticator();
            $cognitoAuthenticator->registerUserWithMetadata($user_id = "");
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            return wp_send_json_error($errorMessage);
        }
    }
}

registerUserWithMetadata::init();