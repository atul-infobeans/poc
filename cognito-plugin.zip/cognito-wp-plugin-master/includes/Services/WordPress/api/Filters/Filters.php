<?php

namespace ICC\API;
/**
 * Defines the filters used on the Endpoint class.
 *
 * @package ICC/Endpoints
 */
class Filters
{
    const API_NAMESPACE = 'icc_endpoints_api_namespace';
    const API_VERSION = 'icc_endpoints_api_version';
    const API_DATA = 'icc_endpoints_data';
    const ITEM_FORMAT = 'icc_endpoints_collection_item';
}
