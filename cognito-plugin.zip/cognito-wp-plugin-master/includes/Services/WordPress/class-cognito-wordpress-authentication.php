<?php


class CognitoWordpressAuthentication
{
    private $user_id;

    public function __construct()
    {
    }

    /**
     * @param $cognitoUsername
     * @param $userEmail
     * @param string $userGivenName
     * @param string $userFamilyName
     * @param array $userMetaItems
     */
    public function createWPUser($cognitoUsername, $userEmail, $userGivenName = "", $userFamilyName = "", $userMetaItems = [])
    {
        $role = get_option('aws_settings')['aws_role_setting'];
        $userId = wp_insert_user([
            'user_login' => $cognitoUsername,
            'user_pass' => wp_generate_password(32, true, false),
            'user_email' => $userEmail,
            'first_name' => $userGivenName,
            'last_name' => $userFamilyName,
            'display_name' => $userGivenName . " " . $userFamilyName,
            'role' => $role,
        ]);
        if (!empty($userId) && !is_wp_error($userId)) {
            $this->user_id = $userId;
        }
        // ADD CUSTOM META
        foreach ($userMetaItems as $key => $value) {
            update_user_meta($this->user_id, $key, $value);
        }
    }

    /**
     * @param $userEmail
     */
    public function loginWpUser($userEmail)
    {
        $WPUserObject = get_user_by('email', $userEmail);
        //wp_clear_auth_cookie(); /** disable this to logged in admin without cognito */
        wp_set_current_user($WPUserObject->ID);
        wp_set_auth_cookie($WPUserObject->ID);
        exit();
    }

/**
	 *
	 * Abila User Login
	 *
	 * @return array $user contains login status and other informations
	 */
	public function cognitoUserLogin($userEmail, $user_data) {
		// @codingStandardsIgnoreStart
        $cookie_name   = md5( "cognito_ck_{$userEmail}" );
		if ( isset( $_COOKIE[ $cookie_name ] ) ) {
			return json_decode( stripslashes( base64_decode( $_COOKIE[ $cookie_name ] ) ), true );
		} // @codingStandardsIgnoreEnd
		$response = array(
			'code'    => 200,
			'status'  => 'success',
			'message' => 'Authenticated successfully!',
			'data'    => $user_data,
		);
		// @codingStandardsIgnoreStart
		setcookie( $cookie_name, base64_encode( wp_json_encode( $response ) ) );
		setcookie( base64_encode( 'useremail' ), base64_encode( $userEmail ) );
		// @codingStandardsIgnoreEnd
		return $response;
	}



    public function logOutUserExtraSecurity()
    {
        wp_set_current_user(0);
        exit();
    }

    public function modifyAuthenticationFilters($user, $username, $password)
    {
        return $user;
    }

}