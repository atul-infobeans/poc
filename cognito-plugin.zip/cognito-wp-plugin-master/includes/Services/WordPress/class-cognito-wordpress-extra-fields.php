<?php


class CognitoWordpressExtraFields
{


    public function __construct()
    {
        add_action('register_form', [$this, 'addExtraRegisterFields']);

        /** Hook your code to the login / Sign up page **/
        add_action('login_head', function(){

            /* Style to hide the user_name field group */
            ?>
            <style>
                #registerform > p:first-child{
                    display:none;
                }
            </style>

            <script type="text/javascript">
                /* Execute this action when the DOM is ready AND after everything in the page is loaded */
                let user_email;
                window.addEventListener('load',function() {
                    user_email = document.querySelector('[name="user_email"]');
                    if(user_email) { // Execute only if there is a user_email field on page
                        user_email.addEventListener('keyup',syncUserName);
                        user_email.addEventListener('change',syncUserName);
                    }
                });

                /* sync user_email's value with the hidden user_login field */
                function syncUserName() {
                    document.querySelector('[name="user_login"]').value = user_email.value.replace('+', "something"); //n.v.stankov+test1231omg@gmail.com
                }

            </script>
            <?php
        });
    }
    public function addExtraRegisterFields()
    {
        $password = !empty($_POST['password']) ? intval($_POST['password']) : '';
        $given_name = !empty($_POST['given_name']) ? intval($_POST['given_name']) : '';
        $family_name = !empty($_POST['family_name']) ? intval($_POST['family_name']) : '';
        $security_question = !empty($_POST['security_question']) ? intval($_POST['security_question']) : '';
        $security_answer = !empty($_POST['security_answer']) ? intval($_POST['security_answer']) : '';
        ?>
        <p>
            <label for="password"><?php esc_html_e('Password', 'crf') ?><br/>
                <input type="password"
                       step="1"
                       id="password"
                       name="password"
                       value="<?php echo esc_attr($password); ?>"
                       class="input"
                />
            </label>
        </p>
        <p>
            <label for="given_name"><?php esc_html_e('Given Name', 'crf') ?><br/>
                <input type="text"
                       step="1"
                       id="given_name"
                       name="given_name"
                       value="<?php echo esc_attr($given_name); ?>"
                       class="input"
                />
            </label>
        </p>
        <p>
            <label for="family_name"><?php esc_html_e('Family Name', 'crf') ?><br/>
                <input type="text"
                       step="1"
                       id="family_name"
                       name="family_name"
                       value="<?php echo esc_attr($family_name); ?>"
                       class="input"
                />
            </label>
        </p>
        <p>
            <label for="security_question"><?php esc_html_e('Security Question', 'crf') ?><br/>
                <input type="text"
                       step="1"
                       id="security_question"
                       name="security_question"
                       value="<?php echo esc_attr($security_question); ?>"
                       class="input"
                />
            </label>
        </p>
        <p>
            <label for="security_answer"><?php esc_html_e('Security Answer', 'crf') ?><br/>
                <input type="text"
                       step="1"
                       id="security_answer"
                       name="security_answer"
                       value="<?php echo esc_attr($security_answer); ?>"
                       class="input"
                />
            </label>
        </p>
        <?php
    }
}