<?php


class CognitoWordpressPlugables
{
    public function __construct()
    {
        $this->loadPluggablesRecrusively();
    }

    public function loadPluggablesRecrusively()
    {
        $plugable_dir = plugin_dir_path(dirname(__FILE__)) . 'WordPress/plugable/';
        //include CPTs
        if (is_dir($plugable_dir)) {
            if ($plugable_dh = opendir($plugable_dir)) {
                while (($plugable_file = readdir($plugable_dh)) !== false) {
                    if (!empty($plugable_file) && $plugable_file != '.' && $plugable_file != '..' && false !== strpos($plugable_file, '.php')) {
                        $cpt_included = require_once($plugable_dir . $plugable_file);
                        if (false === $cpt_included) {
                            error_log('Error in including plugable file_name' . $plugable_dir, 0);
                        }
                    }
                }
                closedir($plugable_dh);
            }
        }
    }
}