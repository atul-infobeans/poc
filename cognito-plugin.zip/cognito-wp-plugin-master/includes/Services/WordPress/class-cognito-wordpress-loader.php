<?php

class CognitoWordpressLoader
{
    private $loader;
    private $wp_pluggables;
    private $wp_ajax_loader;
    private $wp_api_loader;
    private $wp_extra_loader;

    public function __construct()
    {
        $this->loader = $this->load_dependencies();
        $this->wp_pluggables = new CognitoWordpressPlugables();
        $this->wp_ajax_loader = $this->loadAjaxCalls();
        $this->wp_api_loader = $this->loadAPIEndpoints();
        $this->wp_extra_loader = new CognitoWordpressExtraFields();
    }

    public function load_dependencies()
    {

        require_once plugin_dir_path(dirname(__FILE__)) . 'WordPress/class-cognito-wordpress-authentication.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'WordPress/class-cognito-wordpress-plugables.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'WordPress/class-cognito-wordpress-extra-fields.php';

        //Abstract Class
        require_once plugin_dir_path(dirname(__FILE__)) . 'WordPress/ajax/class-cognito-wordpress-ajax.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'WordPress/api/class-cognito-wordpress-api.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'WordPress/api/Filters/Filters.php';

    }

    public function loadAjaxCalls()
    {
        $plugable_dir = plugin_dir_path(dirname(__FILE__)) . 'WordPress/ajax/calls/';
        //include class extensions
        if (is_dir($plugable_dir)) {
            if ($plugable_dh = opendir($plugable_dir)) {
                while (($plugable_file = readdir($plugable_dh)) !== false) {
                    if (!empty($plugable_file) && $plugable_file != '.' && $plugable_file != '..' && false !== strpos($plugable_file, '.php')) {
                        $cpt_included = require_once($plugable_dir . $plugable_file);
                        if (false === $cpt_included) {
                            error_log('Error in including plugable file_name' . $plugable_dir, 0);
                        }
                    }
                }
                closedir($plugable_dh);
            }
        }
    }

    public function loadAPIEndpoints()
    {
        $plugable_dir = plugin_dir_path(dirname(__FILE__)) . 'WordPress/api/Endpoints/';
        //include class extensions
        if (is_dir($plugable_dir)) {
            if ($plugable_dh = opendir($plugable_dir)) {
                while (($plugable_file = readdir($plugable_dh)) !== false) {
                    if (!empty($plugable_file) && $plugable_file != '.' && $plugable_file != '..' && false !== strpos($plugable_file, '.php')) {
                        $cpt_included = require_once($plugable_dir . $plugable_file);
                        if (false === $cpt_included) {
                            error_log('Error in including plugable file_name' . $plugable_dir, 0);
                        }
                    }
                }
                closedir($plugable_dh);
            }
        }
    }

}