<?php

/**
 * CognitoWordPressAjax
 *
 * A simple class for creating active
 * record, eloquent-esque models of WordPress Posts.
 *
 * @author     AnthonyBudd <anthonybudd94@gmail.com>
 * @modified by Nikolay Stankov <nstankov@iccsafe.org>
 *
 * Github : https://github.com/anthonybudd/WP_AJAX
 */
abstract class CognitoWordPressAjax
{
    public $request;
    public $calls;
    public $wp;
    public $user;
    protected $action;

    public function __construct()
    {
        global $wp;
        $this->wp = $wp;
        $this->request = $_REQUEST;
    }

    public static function boot()
    {
        $class = self::getClassName();
        $action = new $class;
        $action->run();
        die();
    }

    public static function getClassName()
    {
        return get_called_class();
    }


    // -----------------------------------------------------
    // UTILITY METHODS
    // -----------------------------------------------------

    public static function listen($action, $public = true)
    {
        $className = self::getClassName();
        add_action("wp_ajax_{$action}", [$className, 'boot']);

        if ($public) {
            add_action("wp_ajax_nopriv_{$action}", [$className, 'boot']);
        }
    }

    public static function action()
    {
        $class = self::getClassName();
        $reflection = new ReflectionClass($class);
        $action = $reflection->newInstanceWithoutConstructor();
        if (!isset($action->action)) {
            throw new Exception("Public property \$action not provied");
        }

        return $action->action;
    }

    abstract protected function run();
}
