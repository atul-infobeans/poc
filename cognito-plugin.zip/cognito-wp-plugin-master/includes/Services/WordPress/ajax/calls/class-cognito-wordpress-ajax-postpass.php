<?php

const POSTPASS_AJAX_ACTION = "postpass-action";

class PostPassAction extends CognitoWordPressAjax
{

    protected function run()
    {
        var_dump($_POST);
        wp_die();
    }
}

PostPassAction::listen(POSTPASS_AJAX_ACTION, true);