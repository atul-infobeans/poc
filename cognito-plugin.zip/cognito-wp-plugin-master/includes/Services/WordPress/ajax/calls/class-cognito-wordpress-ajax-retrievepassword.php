<?php

const RETRIEVEPASSWORD_AJAX_ACTION = "retrievepassword-action";

class RetrievePasswordAction extends CognitoWordPressAjax
{

    protected function run()
    {
        var_dump($_POST);
        wp_die();
    }
}

RetrievePasswordAction::listen(RETRIEVEPASSWORD_AJAX_ACTION, true);