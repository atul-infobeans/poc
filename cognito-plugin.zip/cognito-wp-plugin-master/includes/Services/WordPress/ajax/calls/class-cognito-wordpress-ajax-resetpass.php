<?php

const RESETPASS_AJAX_ACTION = "resetpass-action";

class ResetPassAction extends CognitoWordPressAjax
{

    protected function run()
    {
        var_dump($_POST);
        wp_die();
    }
}

ResetPassAction::listen(RESETPASS_AJAX_ACTION, true);