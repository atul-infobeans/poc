<?php

use pmill\AwsCognito\Exception\CognitoResponseException;

const LOGIN_AJAX_ACTION = "login-action";

class LoginAction extends CognitoWordPressAjax
{
    /*
     * @var cognitoAuthenticator
     */
    private $cognitoAuthenticator;

    protected function run()
    {

        $username = esc_sql($_POST['username']);
        $password = esc_sql($_POST['password']);
        $this->cognitoAuthenticator = new CognitoAuthenticator();
        try {
            $response = $this->cognitoAuthenticator->authViaEmail($username, $password);
            wp_send_json_success($response);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            wp_send_json_error($errorMessage);
        }
    }
}

LoginAction::listen(LOGIN_AJAX_ACTION, true);