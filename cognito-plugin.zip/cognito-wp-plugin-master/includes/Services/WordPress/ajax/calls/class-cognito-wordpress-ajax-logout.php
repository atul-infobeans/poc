<?php

const LOGOUT_AJAX_ACTION = "logout-action";

class LogoutAction extends CognitoWordPressAjax
{

    protected function run()
    {

        $this->cognitoAuthenticator = new CognitoAuthenticator();
        $username = $_POST['username'];
        try {
            $response = $this->cognitoAuthenticator->destroyCookies($username);
            wp_send_json_success($response);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            wp_send_json_error($errorMessage);
        }
    }
}

LogoutAction::listen(LOGOUT_AJAX_ACTION, true);