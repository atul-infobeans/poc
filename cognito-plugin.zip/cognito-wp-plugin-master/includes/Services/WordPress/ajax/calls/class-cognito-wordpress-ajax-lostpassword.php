<?php

use pmill\AwsCognito\Exception\CognitoResponseException;

const LOSTPASSWORD_AJAX_ACTION = "lostpassword-action";

class LostPasswordAction extends CognitoWordPressAjax
{

    protected function run()
    {
        $this->cognitoAuthenticator = new CognitoAuthenticator();
        $username = $_POST['username'];
        try {
            $response = $this->cognitoAuthenticator->resetPassword($username);
            wp_send_json_success($response);
        } catch (Exception $e) {
            $errorMessage = $e->getPrevious()->getAwsErrorMessage();
            wp_send_json_error($errorMessage);
        }
    }
}

LostPasswordAction::listen(LOSTPASSWORD_AJAX_ACTION, true);