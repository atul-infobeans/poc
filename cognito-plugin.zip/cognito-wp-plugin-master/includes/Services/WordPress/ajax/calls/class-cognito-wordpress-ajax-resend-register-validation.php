<?php

use pmill\AwsCognito\Exception\CognitoResponseException;

const RESEND_REGISTER_VALIDATION_AJAX_ACTION = "resend-register-validation-action";

class ResendRegisterValidationAction extends CognitoWordPressAjax
{

    protected function run()
    {

        if (isset($_POST['email'])) {
            $email = $_POST['email'];
            $email = esc_sql($email);
            $class = new CognitoAuthenticator();
            try {
                $response = $class->resendRegistrationConfirmationCode($email);
                wp_send_json_success($response);
            } catch (Exception $e) {
                $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                wp_send_json_error($errorMessage);
            }
        }
    }
}

ResendRegisterValidationAction::listen(RESEND_REGISTER_VALIDATION_AJAX_ACTION, true);