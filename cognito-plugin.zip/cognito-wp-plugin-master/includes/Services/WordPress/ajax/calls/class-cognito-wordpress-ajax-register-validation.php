<?php

use pmill\AwsCognito\Exception\CognitoResponseException;

const REGISTER_VALIDATION_AJAX_ACTION = "register-validation-action";

class RegisterValidationAction extends CognitoWordPressAjax
{

    protected function run()
    {

            if (isset($_POST['email']) && isset($_POST['validation_code'])) {
                $email = $_POST['email'];
                $validation_code = $_POST['validation_code']; // display the results

                $email = esc_sql($email);
                $validation_code = esc_sql($validation_code);

                $class = new CognitoAuthenticator();
                try {
                    $response = $class->validateNewAccount($validation_code, $email);
                    wp_send_json_success($response);
                } catch (Exception $e) {
                    $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                    wp_send_json_error($errorMessage);
                }
            }
    }
}

RegisterValidationAction::listen(REGISTER_VALIDATION_AJAX_ACTION, true);