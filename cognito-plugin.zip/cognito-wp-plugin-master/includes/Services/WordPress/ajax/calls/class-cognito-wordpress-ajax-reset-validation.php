<?php

use pmill\AwsCognito\Exception\CognitoResponseException;

const RESET_VALIDATION_AJAX_ACTION = "reset-validation-action";

class ResetValidationAction extends CognitoWordPressAjax
{

    protected function run()
    {
            if (isset($_POST['email']) && isset($_POST['validation_code'])) {
                $email = $_POST['email'];
                $password = $_POST['password'];
                $validation_code = $_POST['validation_code']; // display the results

                $email = esc_sql($email);
                $validation_code = esc_sql($validation_code);
                $password = esc_sql($password);

                $class = new CognitoAuthenticator();
                try {
                    $response = $class->passwordResetValidation($validation_code, $email, $password);
                    wp_send_json_success($response);
                } catch (Exception $e) {
                    $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                    wp_send_json_error($errorMessage);
                }
                exit;
            }
    }
}

ResetValidationAction::listen(RESET_VALIDATION_AJAX_ACTION, true);