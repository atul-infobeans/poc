<?php

use pmill\AwsCognito\Exception\CognitoResponseException;

const REGISTER_AJAX_ACTION = "register-action";

class RegisterAction extends CognitoWordPressAjax
{

    protected function run()
    {
            $this->cognitoAuthenticator = new CognitoAuthenticator();
            try {
                $response = $this->cognitoAuthenticator->registerUserInCognito();
                wp_send_json_success($response);
            } catch (Exception $e) {
                $errorMessage = $e->getPrevious()->getAwsErrorMessage();
                wp_send_json_error($errorMessage);
            }
    }
}

RegisterAction::listen(REGISTER_AJAX_ACTION, true);