<?php

const RP_AJAX_ACTION = "rp-action";

class RPAction extends CognitoWordPressAjax
{

    protected function run()
    {
        var_dump($_POST);
        wp_die();
    }
}

RPAction::listen(RP_AJAX_ACTION, true);