 jQuery(document).ready(function(){
     jQuery(document).on('click', function (e) {
         let target = jQuery(e.target);
         if (target[0].hasAttribute('cbox-width')) {
             e.preventDefault();
             e.stopPropagation();
             jQuery.colorbox({
                 href: target.attr('href'),
                 width: target.attr("cbox-width"),
                 height: target.attr("cbox-height"),
                 scrolling: false,
             });
             return false;
         }
    });

    /* This function is used to save capabilites of role */
    jQuery('body').on('click','#customLoginBtn',function(){
          jQuery('.spinner').show();
          jQuery("#CustomLoginForm .error").html("");
          jQuery("#CustomLoginForm .alert").removeClass("alert-danger");
          jQuery("#CustomLoginForm .alert").removeClass("alert-success");

          var additional = jQuery("input[name=additional]").val();
          if(additional=='true'){
            var method = jQuery("input[name='method']:checked").val();
          }else{
            var method = jQuery("input[name=method]").val();
          }
          
          var CustomLoginForm = jQuery('#CustomLoginForm').serialize();
          jQuery.ajax({
            type:    "POST",
            url:     MBAjax.ajaxurl,
            data: {
              action: "check_login",
              method: method,
              username: jQuery("input[name=username]").val(),
              password: jQuery("input[name=password]").val(),
              password: jQuery("input[name=password]").val(),
			  ctencpi: jQuery("#ctencpi").val(),
              'check-login' : jQuery("input[name=check-login]").val(),
          },
            success: function(data) {
              var result = jQuery.parseJSON(data);
              if(result['success']==false){
               jQuery("#CustomLoginForm #alert").addClass("alert alert-danger"); 
               jQuery("#CustomLoginForm .error").html(result['msg']);
              }else{
                jQuery("#CustomLoginForm #alert").addClass("alert alert-success"); 
                jQuery("#CustomLoginForm .error").html(result['msg']);
                setTimeout(function() {
                  window.location.href = result['doc_url'];
                    
                }, 2000);
              }
            },
            complete: function(){
              jQuery('.spinner').hide();
            }
          });
          return false;
      }); 

      /* This function is used to save capabilites of role */
      jQuery('.report_file_download').click(function(e){
          e.preventDefault();
          jQuery.ajax({
                type:    "POST",
                url:     MBAjax.ajaxurl,
                data: {
                    action: "setPdfSession",
                },
                success: function(data) {
                  location.reload();
                }
          });
      });
});

/* Colorbox resize function */
var resizeTimer;
function resizeColorBox()
{
    if (resizeTimer) clearTimeout(resizeTimer);
    resizeTimer = setTimeout(function() {
            if (jQuery('#cboxOverlay').is(':visible')) {
                jQuery.colorbox.load(true);
            }
    }, 300)
}

// Resize Colorbox when resizing window or changing mobile device orientation
jQuery(window).resize(resizeColorBox);
window.addEventListener("orientationchange", resizeColorBox, false);