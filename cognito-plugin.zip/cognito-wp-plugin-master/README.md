<h1 align="center">Welcome to ICC-SSO-2.0 👋</h1>
<h2> Testers welcome. v1.0.6</h2>
<p>
  <img alt="Version" src="https://img.shields.io/badge/version-1.0.6-green.svg?cacheSeconds=2592000" />
</p>

> WP Implementation of ICC Cerberus Authentication (Cognito)

### 🏠 [Homepage](https://www.iccsafe.org)

## Install

```sh
composer install
```

After install, activate plugin.  
After activation, connect with an active ICC Developer, to obtain all keys needed.  
To get the app running, one needs:  

AWS ID:  
AWS Secret:  
AWS Client ID:  
AWS Client Secret:  
AWS Region:  
AWS User Pool ID:  
Cookie Domain:  
Cookie Secure:  
Cognito Token Field:  
SSO Login Portal URL:  
User Role:  
Development Mode:  

## Authors

👤 ** Dana Kolodziejczyk **

* Github: [@dkolodziejczyk-icc](https://github.com/dkolodziejczyk-icc)

👤 ** Nikolay Stankov **

* Github: [@nstankovicc](https://github.com/nstankovicc)

## Show your support

Give a ⭐️ if this project helped you!

***
_This README was generated with ❤️ by [readme-md-generator](https://github.com/kefranabg/readme-md-generator)_

<hr>
<h1>Plugin Options</h1>

<h2>Main Settings</h2>

https://{{site_url}}/wp-admin/admin.php?page=cognito-login  

Page for settings, that are going to be stored under wp_options -- aws_settings.

AWS ID:  
AWS Secret:  
AWS Client ID:  
AWS Client Secret:  
AWS Region:  
AWS User Pool ID:  
Cookie Domain:  
Cookie Secure:  
Cognito Token Field:  
SSO Login Portal URL:  
User Role:  
Development Mode:  

<h2>Shortcode List</h2>

https://{{site_url}}/wp-admin/admin.php?page=cognito-login&tab=shortcode <br>
Lists all currently available shortcodes for implementation, if development mode is enabled.

```
[login_form] 	
```

<h2>Ajax Actions List</h2>
https://{{site_url}}/wp-admin/admin.php?page=cognito-login&tab=ajax  <br>
Lists all currently available ajax actions, with examples, if development mode is enabled.

<h2>API List</h2>
https://{{site_url}}/wp-admin/admin.php?page=cognito-login&tab=swagger <br> 
Hosts a link to OpenAPI, IF development mode is enabled.

Place this shortcode on any page, to create a self-contained page, which will handle all actions.
<hr>
## Plugin Structure

Within this plugin, you will find four major directories.

**1.Admin**  
--Holds all back-end related fields and data.  
**2.Includes**  
--Holds all files, that are to be used by both the front-end and back-end.  
**3.Public**  
--Holds all files, that are to be used by the front-end.  
**4.Vendor**  
--Holds all dependencies, such as the Cognito Component.  

## Admin Classes
CognitoLoginAdmin()  
CognitoLoginSettings()  

## Includes Classes

CognitoLogin() -- Main Class.

CognitoLoginActivator() -- Hooks executed on plugin activation.

CognitoLoginDeactivator() -- Hooks executed on plugin deactivation.

## -- Services --
### --- Cognito ---
CognitoAuthenticator() -- Class, that deals with all items Cognito. 

The same includes:

-- Local AWS Settings, pulled from Options Table; ( aws_settings );

-- Cognito Client -- The Cognito Client used, for all LOCAL OPERATIONS;

-- Cognito Cookie Client -- The cognito client used for all operations SSO, that have to deal with the cookies;

-- Cognito Container -- Simple Guzzle with a wrapper. It's job is to call the auth-portal;

-- wpUserAuthentication -- Deals with any WP Authentication.
### --- Loader ---
CognitoLoginLoader() -- Helper class, that deals with loading actions and filters

### --- WordPress ---
CognitoWordpressAuthentication() -- Class that deals with WordPress Authentication.

>CreateWpUser --- Takes a username, email, givenName, givenFamilyName, MetaItems

All of those are standard, but for customization, a developer might want to pass items to MetaItems.
They will be created in wp_usermeta, and bound to the specific user.

>loginWpUser -- Takes user's email.
Once we know that the user is authanticated with COGNITO, we use this method, to log-in the user.


CognitoWordpressAuthentication() -- Creates any Extra Fields that we require in native WP Login.

CognitoWordpressLoader() -- HelperClass, that loads any dependencies.

CognitoWordpressPlugables() -- HelperClass, that loads any plugables, that are ought to overwrite core functiunality.
### --- Ajax ---
Reffer to readme.md in /cognito-wp-plugin/includes/Services/WordPress/ajax/readme.md

Calls folder:  
This is the folder, which creates all AJAX Calls. If one creates an extra call, they can reffer to the document above, to make it public or private(authenticated).

### -- API --
AbstractEndpoint() -- Abstract Class to help in creating endpoints.
Endpoints, individual final classes, within the same directory.

All endpoints on the site are OpenAPI documented.

<hr>


## - Examples -


### -- API Examples --

To use this, go to the plugin settings, and put the plugin in develoment mode.  
After that, navigate to https://{{siteUrl}}/wp-admin/options-general.php?page=swagger-ui  
The Documentation will be displayed in a DOC URL.  

### - Ajax Examples - 
The following ajax actions are registered as public:

<b>login-action</b>
```javascript
function loginActionAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'login-action',
        username: 'n.v.stankov+test1@gmail.com',
        password: '123456a@#A'
    }, function (data) {
        <!-- Handle Error -->
    }, 'JSON');
    return false;
}
```
<b>logout-action</b>
```javascript
function logOutActionAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'logout-action',
        username: 'n.v.stankov+test1@gmail.com',
    }, function (data) {
        <!-- Handle Error -->
    }, 'JSON');
    return false;
}
```
<b>lostpassword-action</b>
```javascript
function lostPasswordAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'lostpassword-action',
        nonce: arr[1],
        username: 'n.v.stankov+test1@gmail.com',
    }, function (data) {
        <!-- Handle Error -->
    }, 'JSON');
    return false;
}
```
<b>postpass-action & register-action</b>
```javascript
function registerActionAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'register-action',
        nonce: arr[1],
        email: jQuery('#user_email').val(),
        password: jQuery('#password').val(),
        given_name: jQuery('#given_name').val(),
        family_name: jQuery('#family_name').val(),
        security_question: jQuery('#security_question').val(),
        security_answer: jQuery('#security_answer').val(),
    }, function (data) {
        <!-- Handle Error -->
    }, 'JSON');
    return false;
}
```
<b> register-validation-action </b>

```javascript
function registerValidationAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'register-validation-action',
        validationCode: jQuery('#validation_code').val(),
        email: jQuery('#email').val(),
    }, function (data) {
        <!-- Handle Error -->
    }, 'JSON');
    return false;
}

```
<b> reset-validation-action </b>

```javascript
function resetValidationAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'reset-validation-action',
        email: jQuery('#email').val(),
        password: jQuery('#password').val(),
        validation_code: jQuery('#validation_code').val(),
        nonce: arr[1],
    }, function (data) {
        <!-- Handle Error -->
    }, 'JSON');
    return false;
}
```
<b>resetpass-action & retrievepassword-action & rp-action</b>
