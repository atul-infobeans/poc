<?php

/**
 * The admin-specific functionality of the plugin.
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 */
class CognitoLoginAdmin
{
    /**
     * CognitoLoginAdmin constructor.
     * @param $plugin_name
     * @param $version
     */

    private $plugin_name;
    private $version;
    private $views;
    private $swagger;
    private $aws_settings;

    public function __construct($plugin_name, $version)
    {
        $this->plugin_name = $plugin_name;
        $this->version = $version;
        $this->views = trailingslashit(plugin_dir_path(dirname(__FILE__)) . 'admin/views');
        $this->aws_settings = get_option('aws_settings');
        $this->swagger = $this->load_swagger();
    }

    /**
     * Loads Swagger Include
     */
    public function load_swagger()
    {
        if ($this->aws_settings['development_mode'] == 1) {
            require_once(trailingslashit(plugin_dir_path(dirname(__FILE__)) . 'admin/includes/wp-api-swaggerui') . "wp-api-swaggerui.php");
        }
    }

    /**
     *  Add item to wordpress admin side menu
     */
    public function add_menu_items()
    {
        add_menu_page(
            'ICC SSO',
            'ICC SSO',
            apply_filters('aws/settings_capabilities', 'manage_options'),
            'cognito-login',
            array($this, 'display_settings_page'),
            'dashicons-admin-network',
            '999'
        );
    }

    /**
     *  Display setting page views
     */
    public function display_settings_page()
    {
        include_once $this->views . 'settings-page.php';
    }

    /**
     *  Create settings
     */
    public function create_settings()
    {
        $settings = new CognitoLoginSettings();
        $settings->register();
    }

    /**
     *  Register and enqueue style
     */
    public function enqueue_admin_styles()
    {
        wp_register_style('aws-admin-css', plugin_dir_url(__FILE__) . 'assets/css/admin.css', '', $this->version);
        wp_enqueue_style('aws-admin-css');
    }
}
