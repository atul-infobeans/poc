<?php
/**
 * Displays the UI for editing Cognito Login
 */

// Handle the active tab
if (isset($_GET['tab'])) {
    $active_tab = $_GET['tab'];
} else {
    $active_tab = "main_setting";
}
?>

<div class="wrap">

    <h2 class="nav-tab-wrapper">
        <a href="?page=cognito-login&tab=main_setting"
           class="nav-tab <?php echo $active_tab == 'main_setting' ? 'nav-tab-active' : ''; ?>">Main settings</a>
        <?php if ($this->aws_settings['development_mode'] == 1): ?>
            <a href="?page=cognito-login&tab=shortcode"
               class="nav-tab <?php echo $active_tab == 'shortcode' ? 'nav-tab-active' : ''; ?>">Shortcode list</a>
            <a href="?page=cognito-login&tab=ajax"
               class="nav-tab <?php echo $active_tab == 'ajax' ? 'nav-tab-active' : ''; ?>">Ajax actions list</a>
            <a href="?page=cognito-login&tab=swagger"
               class="nav-tab <?php echo $active_tab == 'swagger' ? 'nav-tab-active' : ''; ?>">Swagger Documentations
                Page</a>
        <?php endif; ?>
    </h2>

    <div class='aws-cognito-setting-box'>
        <?php
        if ($active_tab == 'main_setting') :
            echo '<form method="post" action="options.php">';
            //Display option field for the setting form
            settings_fields('aws_settings');

            //Display UI for the setting form
            do_settings_sections('aws-section');

            submit_button();
            echo '</form>';

        elseif ($active_tab == 'shortcode') :
            ?>
            <h2> Shortcode List </h2>
            <br>
            <table class='aws-cognito-setting-table'>
                <tr>
                    <td class='table-shortcode-row'>[login_form]</td>
                    <td>
                        <p> Place this shortcode on any page, to create a self-contained page, which will handle all
                            actions.</p>
                    </td>
                </tr>
            </table>
        <?php elseif ($active_tab == 'ajax') : ?>
            <h2> Admin Ajax Actions List </h2>
            <p>All actions listed below use a POST action.</p>
            <br>
            <table class='aws-cognito-setting-table'>
                <tr>
                    <td class='table-shortcode-row'>login-action</td>
                    <td>
                        <p>Takes two parameters : $username -- expected User Email and $password</p>
                        <p style="text-align:center"> Example Usage: </p>
                        <code>
                            jQuery('#wp-submit').click(function () { <br>
                            jQuery.post('https:local.wpcognito.com/wp-admin/admin-ajax.php', { <br>
                            action: 'login-action', <br>
                            username : jQuery('#email').val(), <br>
                            password : jQuery('#password').val(), <br>
                            }, function (data) { <br>
                            console.log(data) <br>
                            }, 'JSON');<br>
                            });
                        </code>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>logout-action</td>
                    <td>
                        <p>Takes one parameter : $username -- expected User Email </p>
                        <p style="text-align:center"> Example Usage: </p>
                        <code>
                            jQuery('#wp-submit').click(function () { <br>
                            jQuery.post('https:local.wpcognito.com/wp-admin/admin-ajax.php', { <br>
                            action: 'logout-action', <br>
                            username : jQuery('#email').val(), <br>
                            }, function (data) { <br>
                            console.log(data) <br>
                            }, 'JSON');<br>
                            });
                        </code>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>lostpassword-action</td>
                    <td>
                        <p>Takes one parameter : $username -- expected User Email </p>
                        <p style="text-align:center"> Example Usage: </p>
                        <code>
                            jQuery('#wp-submit').click(function () { <br>
                            jQuery.post('https:local.wpcognito.com/wp-admin/admin-ajax.php', { <br>
                            action: 'lostpassword-action', <br>
                            username : jQuery('#email').val(), <br>
                            }, function (data) { <br>
                            console.log(data) <br>
                            }, 'JSON');<br>
                            });
                        </code>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>postpass-action</td>
                    <td>
                        <p>Not Used, but set atm.</p>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>register-action</td>
                    <td>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>register-validation-action</td>
                    <td>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>reset-validation-action</td>
                    <td>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>resend-register-validation-action</td>
                    <td>
                        <p>Takes one parameter : $username -- expected User Email </p>
                        <p style="text-align:center"> Example Usage: </p>
                        <code>
                            jQuery('#wp-submit').click(function () { <br>
                            jQuery.post('https:local.wpcognito.com/wp-admin/admin-ajax.php', { <br>
                            action: 'resend-register-validation-action', <br>
                            email : jQuery('#email').val(), <br>
                            }, function (data) { <br>
                            console.log(data) <br>
                            }, 'JSON');<br>
                            });
                        </code>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>resetpass-action</td>
                    <td>
                        <p>Not Used, but set atm.</p>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>retrievepassword-action</td>
                    <td>
                        <p>Not Used, but set atm.</p>
                    </td>
                </tr>
                <tr>
                    <td class='table-shortcode-row'>rp-action</td>
                    <td>
                        <p>Not Used, but set atm.</p>
                    </td>
                </tr>
            </table>
        <?php

        elseif ($active_tab = 'swagger'): ?>
            <h2> OpenApi Documentation </h2>
            <br>
            <table class='aws-cognito-setting-table'>
                <tr>
                    <td class='table-shortcode-row'>OpenApi Documentation</td>
                    <td>
                        <a href="<?= site_url("/rest-api/docs/") ?>">URL to documentation.</a>
                    </td>
                </tr>
            </table>
        <?php
        endif;
        ?>
    </div>

</div><!-- .wrap -->
