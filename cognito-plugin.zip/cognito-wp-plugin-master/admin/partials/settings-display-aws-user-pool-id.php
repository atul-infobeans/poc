<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="password" name="aws_settings[aws_user_pool_id]" value="<?php echo $aws_user_pool_id; ?>" placeholder="Input the User Pool ID" />