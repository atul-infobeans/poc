<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="password" name="aws_settings[aws_secret]" value="<?php echo $aws_secret; ?>" placeholder="Input the AWS Secret" />