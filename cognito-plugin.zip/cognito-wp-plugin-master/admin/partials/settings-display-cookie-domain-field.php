<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="text" name="aws_settings[cookie_domain]" value="<?php echo $cookie_domain; ?>" placeholder="Input the Cookie Domain" />