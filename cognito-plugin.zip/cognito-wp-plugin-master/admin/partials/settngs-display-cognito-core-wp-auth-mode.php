<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="text" name="aws_settings[cognito_core_wp_auth_mode]" value="<?php echo $core_plugin_auth_mode; ?>" placeholder="Input 1 for true or 0 for false." />