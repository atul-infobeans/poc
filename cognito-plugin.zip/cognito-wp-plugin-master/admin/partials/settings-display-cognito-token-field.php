<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="password" name="aws_settings[cognito_token]" value="<?php echo $cognito_token; ?>" placeholder="Input the provided token for AUTH Portal" />