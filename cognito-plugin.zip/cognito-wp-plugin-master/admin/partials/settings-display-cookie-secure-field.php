<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="text" name="aws_settings[cookie_secure]" value="<?php echo $cookie_secure; ?>" placeholder="1 or a 0 here" />