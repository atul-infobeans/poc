<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="password" name="aws_settings[aws_region]" value="<?php echo $aws_region; ?>" placeholder="Input the AWS Region" />