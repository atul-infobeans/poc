<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="password" name="aws_settings[aws_id]" value="<?php echo $aws_id; ?>" placeholder="Input AWS ID" />