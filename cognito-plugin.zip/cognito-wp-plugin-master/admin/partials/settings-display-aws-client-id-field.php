<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="password" name="aws_settings[aws_client_id]" value="<?php echo $aws_client_id; ?>" placeholder="Input the AWS Client ID" />