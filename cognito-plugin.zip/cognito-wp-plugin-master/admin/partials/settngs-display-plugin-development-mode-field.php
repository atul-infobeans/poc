<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="text" name="aws_settings[development_mode]" value="<?php echo $development_mode; ?>" placeholder="Input 1 for true or 0 for false." />