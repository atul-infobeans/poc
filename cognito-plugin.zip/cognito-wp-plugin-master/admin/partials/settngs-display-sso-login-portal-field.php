<?php
/**
 * Represents the partial view for where users can enter user pool id
 */
?>

<input type="text" name="aws_settings[sso_login_portal]" value="<?php echo $sso_login_portal; ?>" placeholder="Input the URL of the login portal here." />