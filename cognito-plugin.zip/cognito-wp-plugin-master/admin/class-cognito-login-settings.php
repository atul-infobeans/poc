<?php

class CognitoLoginSettings
{
    private $views;
    public $fields;
    public function __construct()
    {
        $this->views = trailingslashit(plugin_dir_path(dirname(__FILE__)) . 'admin/partials/');

        //Declare field ID and field name
        $this->fields = [
            'aws_id' => 'AWS ID',
            'aws_secret' => 'AWS Secret',
            'aws_client_id' => 'AWS Client ID',
            'aws_client_secret' => 'AWS Client Secret',
            'aws_region' => 'AWS Region',
            'aws_user_pool_id' => 'AWS User Pool ID',
            'cookie_domain' => 'Cookie Domain',
            'cookie_secure' => 'Cookie Secure',
            'cognito_token' => 'Cognito Token Field',
            'sso_login_portal' => 'SSO Login Portal URL',
            'role_setting' => 'User role',
            'cognito_core_wp_auth_mode' => 'Overwrite Core WP Auth',
            'development_mode' => 'Development Mode'

        ];
    }

    /**
     * Register sections fields and settings
     */
    public function register()
    {

        register_setting(
            'aws_settings',        // Group of options
            'aws_settings',                // Name of options
            [$this, 'sanitize']    // Sanitization function
        );

        add_settings_section(
            'aws-main',            // ID of the settings section
            'Main Settings',            // Title of the section
            '',
            'aws-section'        // ID of the page
        );


        foreach ($this->fields as $key => $name) {
            add_settings_field(
                $key,        // The ID of the settings field
                $name,                // The name of the field of setting(s)
                [$this, 'display_' . $key],
                'aws-section',        // ID of the page on which to display these fields
                'aws-main'            // The ID of the setting section
            );
        }
    }

    /**
     * Display user role field
     */
    public function display_aws_id()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_id = isset($opts['aws_id']) ? $opts['aws_id'] : '';
        // And display the view
        include_once $this->views . 'settings-display-aws-id-field.php';
    }

    /**
     * Display user role field
     */
    public function display_aws_secret()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_secret = isset($opts['aws_secret']) ? $opts['aws_secret'] : '';
        // And display the view
        include_once $this->views . 'settings-display-aws-secret-field.php';
    }

    /**
     * Display user role field
     */
    public function display_aws_client_id()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_client_id = isset($opts['aws_client_id']) ? $opts['aws_client_id'] : '';
        // And display the view
        include_once $this->views . 'settings-display-aws-client-id-field.php';
    }

    /**
     * Display user role field
     */
    public function display_aws_client_secret()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_client_secret = isset($opts['aws_client_secret']) ? $opts['aws_client_secret'] : '';
        // And display the view
        include_once $this->views . 'settings-display-aws-client-secret-field.php';
    }

    /**
     * Display user role field
     */
    public function display_aws_region()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_region = isset($opts['aws_region']) ? $opts['aws_region'] : '';
        // And display the view
        include_once $this->views . 'settings-display-aws-region-field.php';
    }

    /**
     * Display user role field
     */
    public function display_aws_user_pool_id()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_user_pool_id = isset($opts['aws_user_pool_id']) ? $opts['aws_user_pool_id'] : '';
        // And display the view
        include_once $this->views . 'settings-display-aws-user-pool-id.php';
    }

    /**
     * Display user role field
     */
    public function display_cookie_domain()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $cookie_domain = isset($opts['cookie_domain']) ? $opts['cookie_domain'] : '';
        // And display the view
        include_once $this->views . 'settings-display-cookie-domain-field.php';
    }

    /**
     * Display user role field
     */
    public function display_cookie_secure()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $cookie_secure = isset($opts['cookie_secure']) ? $opts['cookie_secure'] : '';
        // And display the view
        include_once $this->views . 'settings-display-cookie-secure-field.php';
    }

    /**
     * Display user role field
     */
    public function display_sso_login_portal()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $sso_login_portal = isset($opts['sso_login_portal']) ? $opts['sso_login_portal'] : '';
        // And display the view
        include_once $this->views . 'settngs-display-sso-login-portal-field.php';
    }

    /**
     * Display user role field
     */
    public function display_role_setting()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_role_setting = isset($opts['aws_role_setting']) ? $opts['aws_role_setting'] : '';
        // And display the view
        include_once $this->views . 'settings-display-role-field.php';
    }

    /**
     * Display login button field
     */
    public function display_login_button()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $aws_display_login = isset($opts['aws_display_login']) ? $opts['aws_display_login'] : '';
        // And display the view
        include $this->views . 'settings-display-login-field.php';
    }

    /**
     * Display login button field
     */
    public function display_cognito_token()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $cognito_token = isset($opts['cognito_token']) ? $opts['cognito_token'] : '';
        // And display the view
        include $this->views . 'settings-display-cognito-token-field.php';
    }

    /**
     * Display user role field
     */
    public function display_cognito_core_wp_auth_mode()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $core_plugin_auth_mode = isset($opts['cognito_core_wp_auth_mode']) ? $opts['cognito_core_wp_auth_mode'] : '';
        // And display the view
        include_once $this->views . 'settngs-display-cognito-core-wp-auth-mode.php';
    }

    /**
     * Display user role field
     */
    public function display_development_mode()
    {
        // Now grab the options based on what we're looking for
        $opts = get_option('aws_settings');
        $development_mode = isset($opts['development_mode']) ? $opts['development_mode'] : '';
        // And display the view
        include_once $this->views . 'settngs-display-plugin-development-mode-field.php';
    }

    /**
     * @param $input
     * @return array
     */
    public function sanitize($input)
    {

        $new_input = [];

        // Loop through the input and sanitize each of the values
        foreach ($input as $key => $val) {
            $new_input[$key] = sanitize_text_field($val);
        }

        return $new_input;
    }
}