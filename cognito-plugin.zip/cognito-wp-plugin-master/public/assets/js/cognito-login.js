function loginActionAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'login-action',
        username: '',
        password: ''
    }, function (data) {
        console.log(data)
    }, 'JSON');
    return false;
}

function logOutActionAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'logout-action',
        username: '',
    }, function (data) {
        console.log(data)
    }, 'JSON');
    return false;
}

function registerActionAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'register-action',
        nonce: arr[1],
        email: jQuery('#user_email').val(),
        password: jQuery('#password').val(),
        given_name: jQuery('#given_name').val(),
        family_name: jQuery('#family_name').val(),
        security_question: jQuery('#security_question').val(),
        security_answer: jQuery('#security_answer').val(),
    }, function (data) {
        console.log(data)
    }, 'JSON');
    return false;
}

jQuery('#register-validation').on('click', registerValidationAjax);

function registerValidationAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'register-validation-action',
        validationCode: jQuery('#validation_code').val(),
        email: jQuery('#email').val(),
    }, function (data) {
        console.log(data)
    }, 'JSON');
    return false;
}

jQuery('#reset-validation').on('click', resetValidationAjax);

function resetValidationAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'reset-validation-action',
        email: jQuery('#email').val(),
        password: jQuery('#password').val(),
        validation_code: jQuery('#validation_code').val(),
        nonce: arr[1],
    }, function (data) {
        console.log(data)
    }, 'JSON');
    return false;
}

function lostPasswordAjax() {
    let arr = (Object.values(iccSSO));
    jQuery.post(arr[0], {
        action: 'lostpassword-action',
        nonce: arr[1],
        username: '',
    }, function (data) {
        console.log(data)
    }, 'JSON');
    return false;
}
