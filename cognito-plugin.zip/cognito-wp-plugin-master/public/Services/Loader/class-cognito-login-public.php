<?php


/**
 * Defines the plugin name, version
 * enqueue the admin-specific stylesheet and JavaScript.
 */
class CognitoLoginPublic
{

    /**
     * The ID of this plugin.
     */
    private $plugin_name;

    /**
     * The version of this plugin.
     */
    private $version;

    //Shortcodes
    private $shortcodes;

    //Form Validator
    private $validator;
    /**
     * @var array|null Stores AWS settings.
     */
    private $awsSettings;
    /**
     * CognitoLoginPublic constructor.
     */
    public function __construct()
    {
        $this->awsSettings = get_option('aws_settings');

        $this->plugin_name = "iccSSO";
        $this->load_dependencies();
        $this->validator = new ClassCognitoValidator();

        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_enqueue_styles', [$this, 'enqueue_styels']);
    }

    public function load_dependencies()
    {

        //Public
//        require_once plugin_dir_path(dirname(__FILE__)) . 'Shortcodes/class-cognito-login-shortcodes.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'Validator/class-cognito-honeypot.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'Validator/class-cognito-math-captcha.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'Validator/class-cognito-user-input-filtering.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'Validator/class-cognito-validator.php';

    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     */
    public function enqueue_scripts()
    {
        wp_register_script($this->plugin_name . "_public", plugin_dir_url(dirname(__DIR__)) . 'assets/js/cognito-login.js', ['jquery'], $this->version, true);
        wp_enqueue_script($this->plugin_name . "_public");

        wp_localize_script(
            $this->plugin_name . "_public",
            $this->plugin_name,
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'security' => wp_create_nonce("ajax_security"),
            ]
        );

    }

    /**
     * Register the stylesheets for the public-facing side of the site.
     */
    public function enqueue_styles()
    {
        wp_register_style($this->plugin_name . "_public", plugin_dir_url(dirname(__DIR__)) . 'assets/css/cognito-login.css', [], $this->version, 'all');
        wp_enqueue_style($this->plugin_name . "_public");
    }

}