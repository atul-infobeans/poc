<?php


class ClassCognitoValidator
{
    /**
     * ClassCognitoValidator constructor.
     */

    /*
     * @var $inputValidation;
     */
    private $inputValidation;
    private $mathValidator;

    public function __construct()
    {
        $this->inputValidation = new CognitoUserInputFiltering();
//        $this->mathValidator = new CognitoMath();
    }
}