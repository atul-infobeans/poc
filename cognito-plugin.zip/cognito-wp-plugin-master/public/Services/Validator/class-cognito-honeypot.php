<?php

/**
 * Sets up and initializes the Registration Honeypot plugin.
 *
 * @return void
 * @since  1.0.0
 * @access public
 */
final class CognitoHoneypot
{

    /**
     * Holds the instances of this class.
     *
     * @since  1.0.0
     * @access private
     * @var    object
     */
    private static $instance;

    /**
     * Sets up needed actions/filters for the plugin to initialize.
     *
     * @return void
     * @since  1.0.0
     * @access public
     */
    public function __construct()
    {
        add_action('plugins_loaded', [$this, 'i18n'], 2);
        add_action('login_head', [$this, 'print_styles']);
        add_action('register_form', [$this, 'register_form'], 99);
        add_action('register_post', [$this, 'check_honeypot'], 0);
        add_action('login_form_register', [$this, 'check_honeypot'], 0);
    }

    /**
     * Returns the instance.
     *
     * @return object
     * @since  1.0.0
     * @access public
     */
    public static function get_instance()
    {

        if (!self::$instance)
            self::$instance = new self;

        return self::$instance;
    }

    /**
     * Loads the translation files.
     *
     * @return void
     * @since  1.0.0
     * @access public
     */
    function i18n()
    {
        load_plugin_textdomain('registration-honeypot', false, 'registration-honeypot/languages');
    }

    /**
     * Checks if a spambot stuck his hand in the honeypot.  If so, we'll cut off the user registration
     * process so that the spam user account never gets registered.
     *
     * @return void
     * @since  1.0.0
     * @access public
     */
    public function check_honeypot()
    {

        if (isset($_POST['th_rh_name']) && !empty($_POST['th_rh_name']))
            wp_die(__('You filled out a form field that was created to stop spammers. Please go back and try again or contact the site administrator if you feel this was in error.', 'registration-honeypot'));
    }

    /**
     * Outputs custom CSS to the login head to hide the honeypot field on the user registration form.
     *
     * @return void
     * @since  1.0.0
     * @access public
     */
    public function print_styles()
    { ?>
        <style type="text/css">.th_rh_name_field {
                display: none;
            }</style>
    <?php }

    /**
     * Outputs custom jQuery to make sure the honeypot field is empty by default.
     *
     * @return void
     * @since  1.0.0
     * @access public
     */
    public function print_scripts()
    { ?>
        <script type="text/javascript">jQuery('#th_rh_name').val('');</script>
    <?php }

    /**
     * Adds a hidden field that spambots will fill out but normal humans won't see.  In the off-chance
     * that a real human has CSS disabled on their browser, the label should let them know not to fill
     * out this form field.  This field will be checked to see if the visitor/spambot entered text into
     * it.  This will let us know that they're a spambot.
     *
     * @return void
     * @since  1.0.0
     * @access public
     */
    public function register_form()
    {

        /* Load scripts for register form. */
        wp_enqueue_script('jquery');
        add_action('login_footer', [$this, 'print_scripts'], 25); ?>

        <p class="th_rh_name_field">
            <label for="th_rh_name"><?php _e('Only fill in if you are not human', 'registration-honeypot'); ?></label><br/>
            <input type="text" name="th_rh_name" id="th_rh_name" class="input" value="" size="25"
                   autocomplete="off"/>
        </p>
    <?php }
}

CognitoHoneypot::get_instance();