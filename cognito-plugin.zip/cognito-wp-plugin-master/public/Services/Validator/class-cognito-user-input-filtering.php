<?php

class CognitoUserInputFiltering
{
    public function __construct()
    {
        add_filter('registration_errors', [$this, 'filterWordPressAuthenticationErrors'], 10, 1);
        add_filter('login_errors', [$this, 'filterWordPressAuthenticationErrors'], 10, 1);
    }

    /**
     * @param $errors
     * @return mixed
     */

    public
    function filterWordPressAuthenticationErrors($errors)
    {

        if (isset($_GET['action'])) {
            $get_action = $_GET['action'];
        } else {
            $get_action = "login";
        }
        //Add extra Errors for Registration
        switch ($get_action) {

            case 'login':
                $word = "entered for the email address";
                if(strpos($errors, $word) !== false){
                    $errors = "";
                }

//            case "register":
//                if (empty($_POST['given_name'])) {
//                    $errors->add('given_name_error', __('<strong>Error</strong>: Please enter your given name.', 'crf'));
//                }
//                if (empty($_POST['family_name'])) {
//                    $errors->add('security_answer_error', __('<strong>Error</strong>: Please enter your family name.', 'crf'));
//                }
//                if (empty($_POST['security_question'])) {
//                    $errors->add('security_question_error', __('<strong>Error</strong>: Please enter your security question.', 'crf'));
//                }
//                if (empty($_POST['security_answer'])) {
//                    $errors->add('security_answer_error', __('<strong>Error</strong>: Please enter your security answer.', 'crf'));
//                }
//                //Returns WP_Errors object, which register filter accepts
//                return $errors;
//                break;
//
//            case "lostpassword":
//                break;

            default:
                return $errors;
        }
    }
}