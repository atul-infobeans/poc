<?php

class CognitoMath
{
    private $login_captcha;

    public function __construct()
    {
        $this->login_captcha = $this->generateCaptcha();
        //Actions
        add_action('register_form', [$this, 'MathFormAddition'], 99);
        add_action('login_form', [$this, 'MathFormAddition'], 99);

        //Filters
        add_filter('registration_errors', [$this, 'filterWordPressMathCaptcha'], 10, 1);
        add_filter('login_errors', [$this, 'filterWordPressMathCaptcha'], 10, 1);
        add_filter('wp_authenticate_user', [$this, 'showError'], 10, 1);
    }

    public function generateCaptcha()
    {

        $challenge_options = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine'];
        $challenge_calcs = ['plus', 'minus'];
        // randomly pic if the challenge is addition or subtraction
        $rand_calc = array_rand($challenge_calcs, 1);

        // randomly select first challenge value, and don't allow 0 to prevent a scenario of 0 + zero or 0 - zero
        $first_challenge_val = array_rand($challenge_options, 1);
        while ($first_challenge_val == 0)
            $first_challenge_val = array_rand($challenge_options, 1);

        // randomly select second challenge value
        $second_challenge_val = array_rand($challenge_options, 1);

        $captcha_answer = '';

        switch ($rand_calc) {
            case 0: // Addition
                $captcha_answer = (int)$first_challenge_val + (int)$second_challenge_val;
                break;
            case 1: // Subtraction - when subtraction, apply some logic to ensure there are no negative answers
                // make sure first value is greater than 5
                while ($first_challenge_val < 5)
                    $first_challenge_val = array_rand($challenge_options, 1);
                // make sure second value is less than 4
                while ($second_challenge_val > 4)
                    $second_challenge_val = array_rand($challenge_options, 1);
                $captcha_answer = (int)$first_challenge_val - (int)$second_challenge_val;
                break;
        }
        $question = $first_challenge_val . " " . $challenge_calcs[$rand_calc] . " " . $challenge_options[$second_challenge_val];

        $return = [];

        $return['question'] = $question;

        $return['answer'] = $captcha_answer;

        return $return;
    }

    /**
     *  Utility function
     *  Function creates a random math question and returns question to the requesting page,
     *  The answer is stored in $_SESSION for validation on submit
     *
     * @return string
     */

    public function MathFormAddition()
    {
        $login_captcha = $this->login_captcha; ?>

        <div class="col-12">

            <div class="input-group">
                        <span
                                class="input-group-addon"
                                id="sign-in-input-math">
                            <b><?= $login_captcha['question']; ?></b>
                        </span>
                <input
                        name="input-login-math"
                        type="text"
                        class="form-control sign-in-input-math-field"
                        aria-describedby="sign-in-input-math"
                        placeholder=""
                        value="">
                <input
                        name="input-math-recipe"
                        type="hidden"
                        value="<?= $login_captcha['answer']; ?>">
            </div>
        </div>
        <?php
    }


    /**
     * @param $user
     * @return string
     */

    public function showError($user)
    {
        $MathValidation = $this->ValidateMathField();

        if ($MathValidation['errorCheck'] === false) {
            return $user;
        } else {
            $user = new WP_Error('denied', __("<strong>Error</strong>: Failed Math Captcha Check."));
            return $user;
        }
    }

    /**
     * @return array
     */
    public function ValidateMathField()
    {
        //Set Vars
        if (isset($_POST['input-login-math']) && isset($_POST['input-math-recipe'])) {
            $user_challenge_input = $_POST['input-login-math'];
            $challenge_expected_answer = $_POST['input-math-recipe'];
        }
        $errors = [
            'errorCheck' => false,
            'error' => null,
        ];
        //Validation
        if (empty($user_challenge_input)) {
            $errors = [
                'errorCheck' => true,
                'error' => 'Math Captcha Input is Empty',
            ];
        }
        if (!empty($user_challenge_input) && !empty($challenge_expected_answer) && $user_challenge_input !== $challenge_expected_answer) {
            $errors = [
                'errorCheck' => true,
                'error' => 'Math Captcha Input is Wrong',
            ];
        }

        //If both of the above are not triggered, this will come back as true and will pass validation.
        //Else, it will return an error object, which will display the error to the user.
        return $errors;
    }

    public
    function filterWordPressMathCaptcha($errors)
    {
        if (isset($_GET['action'])) {
            $get_action = $_GET['action'];
        } else {
            $get_action = "login";
        }
        //Add extra Errors for Registration
        switch ($get_action) {

            case "register":

                //Math Captcha
                $MathValidation = $this->ValidateMathField();
                if ($MathValidation['errorCheck'] === true) {
                    $errors->add('math_captcha_error', __('<strong>Error</strong>: Please make sure to answer the math problem correctly.', 'crf'));
                }
                //Returns WP_Errors object, which register filter accepts
                return $errors;
                break;

            case "lostpassword":
                break;

            default:
                return $errors;
        }
    }
}
